(function( $ ) {
  'use strict';
    jQuery(function($)
    {

      /*jQuery.ajax({
        url : doctorVerifiedParams.ajax_url,
        type : 'POST',
        data : {
         'action': 'doctor_verified_check_user_email',
         'txtEmailID' : $( "#txtEmailID" ).val()
        },
        //data:$("#domainForm").serialize(),
        success : function( data ) {
          //console.log(data);
          $("#display-form-result").html(data);

        },
        error:function (){}
      });*/    

      //console.log(doctorVerifiedParams.ajax_url);

     /* jQuery.validator.addMethod("uniqueEmail", function(value, element) {
          var response;
          jQuery.ajax({
              type: "POST",
              url: doctorVerifiedParams.ajax_url,
              data:{
                'action': 'doctor_verified_check_user_email',
                'txtEmailID': $("#txtEmailID").val()
              },
              //async:false,
              success:function(data){
                  response = data;
                  console.log(response);
              }
          });
        
        if(response.toString().trim() == "true")
          {
              return true;
          }
          else
          {
              return false;
          }

      }, "Email is Already Taken");*/


//VALIDATE USER EMAIL
$.validator.addMethod("validateUserEmail", function(value, element)
{
    console.log(value);
    var inputElem = $('#txtEmailID'),
        //data = { 'emails' : inputElem.val() },
        //data = { 'action': 'doctor_verified_check_user_email', 'emails' : inputElem.val() },
        eReport = ''; //error report

    $.ajax(
    {
        type: "POST",
        url: 'http://localhost/wpplugins/web-seal/check-email.php', //doctorVerifiedParams.ajax_url,
        //dataType: "json",
        data: { 'emails' : inputElem.val() },
        success: function(data)
        { 
          //console.log(inputElem.val());
          console.log(data);
            if (data !== 'true')
            {
              return 'This email address is already registered.';
            }
            else
            {
               return true;
            }
        },
        error: function(xhr, textStatus, errorThrown)
        {
            alert('ajax loading error... ... '+url + query);
            return false;
        }
    });

}, '');

//$('#txtEmailID').rules("add", { "validateUserEmail" : true} );


      /*jQuery.validator.addMethod("valDomain", function(value, element) {
        // allow any non-whitespace characters as the host part
        return this.optional( element ) || /(.*?)[^w{3}.]([a-zA-Z0-9]([a-zA-Z0-9-]{0,65}[a-zA-Z0-9])?.)+[a-zA-Z]{2,6}/igm.test( value );
      }, 'Please enter a valid Domain.');*/      

      // a custom method making the default value for companyurl ("http://") invalid, without displaying the "invalid url" message
      jQuery.validator.addMethod("defaultInvalid", function(value, element) {
        return value != element.defaultValue;
      }, "");

      var form = $("#applyform").show();

      form.steps({
          headerTag: "h3",
          bodyTag: "fieldset",
          transitionEffect: "slideLeft",
          onStepChanging: function (event, currentIndex, newIndex)
          {
              // Allways allow previous action even if the current form is not valid!
              if (currentIndex > newIndex)
              {
                  return true;
              }

              // Forbid next action on "Warning" step if the user is to young
              /*if (newIndex === 3 && Number($("#age-2").val()) < 18)
              {
                  return false;
              }*/

              // Needed in some cases if the user went back (clean up)
              if (currentIndex < newIndex)
              {
                  // To remove error styles
                  form.find(".body:eq(" + newIndex + ") label.error").remove();
                  form.find(".body:eq(" + newIndex + ") .error").removeClass("error");
              }

              form.validate().settings.ignore = ":disabled,:hidden";
              return form.valid();
          },
          onStepChanged: function (event, currentIndex, priorIndex)
          {
              // Used to skip the "Warning" step if the user is old enough.
              //if (currentIndex === 2 && Number($("#age-2").val()) >= 18)

              /*if (currentIndex === 2)  
              {
                  form.steps("next");
              }

              // Used to skip the "Warning" step if the user is old enough and wants to the previous step.
              if (currentIndex === 2 && priorIndex === 3)
              {
                  form.steps("previous");
              }*/
          },
          onFinishing: function (event, currentIndex)
          {
              form.validate().settings.ignore = ":disabled";
              return form.valid();
          },
          onFinished: function (event, currentIndex)
          {
            //alert("Submitted!");
            form.get(0).submit();
            //form.submit();
            //console.log(currentIndex);

            //console.log(doctorVerifiedParams.ajax_url);

            //console.log(jQuery("#coupon1").val());
            //console.log(jQuery("#coupon2").val());


            /*jQuery.ajax({
              url : doctorVerifiedParams.ajax_url,
              type : 'POST',
              dataType: 'json',
              data : {
                action : 'doctor_verified_apply',
                coupon1 : 'test1', //jQuery("#coupon1").val(),
                coupon2 : 'test2' //jQuery("#coupon2").val()
              },
              //data:$("#domainForm").serialize(),
              complete: function( xhr, status ){
                  console.log("Request complete: " + status);
              },
              error: function( xhr, status, errorThrown ){
                  console.log("Request failed: " + status);
              },
              success: function( data, status, xhr ){
                  console.log("Request success: " + data);
                  // change the html
                 $("#message").html(data);
              }
            });*/

            /*var data = {
                action: 'doctor_verified_apply',
                'coupon1' : jQuery("#coupon1").val(),
                'coupon2' : jQuery("#coupon2").val()
            };
            jQuery.post(doctorVerifiedParams.ajax_url, data, function(response) {
                jQuery("#message").html(response);
            });*/ 

          },
          /* Labels */
          labels: {
              cancel: "Cancel",
              current: "current step:",
              pagination: "Pagination",
              finish: "Apply",
              next: "Continue",
              previous: "Previous",
              loading: "Loading ..."
          } 
      }).validate({
          errorPlacement: function errorPlacement(error, element) { element.before(error); },
          rules: {
              /*confirm: {
                  equalTo: "#password-2"
              }*/

              txtDomain: {
                required: true,
                defaultInvalid: true,
                url: true
              },
              txtEmailID: {
                required: true,
                email: true,
                //uniqueEmail:true
                //validateUserEmail:true
                /*remote: {
                        url: 'http://localhost/wpplugins/web-seal/check-email.php', //'http://localhost/wpplugins/wp-content/plugins/doctor-verified/check-email.php', //doctorVerifiedParams.ajax_url, //'http://localhost/wpplugins/wp-admin/admin-ajax.php', 
                        type: "post",
                        dataType: "json",
                        data: {
                           'txtEmailID': function() {
                                return jQuery( "#txtEmailID" ).val();
                            },

                           'txtEmailID': jQuery( "#txtEmailID" ).val(),
                           'action': 'doctor_verified_check_user_email'

                        }
                }*/
                "remote":
                {
                  url: 'http://localhost/wpplugins/web-seal/check-email.php',
                  type: "post",
                  data:
                  {
                      email: function()
                      {
                          return $('#applyform :input[name="txtEmailID"]').val();
                      }
                  }
                }
                
              },
              txtNewPassword: {
                required: true,
                minlength: 6,
                maxlength: 25
              }
          }
      });


      $('#yes_coupon').change(function(){
         if($(this).is(":checked")){
          $('#coupon_block').show(); 
         }
         else{
            $('#coupon_block').hide();
            $('#stripe_script_container').show();
         }
      });
      
      $('#no_coupon').change(function(){
         if($(this).is(":checked")){

          //location.href="/web/20160430033815/https://doctor-certified.com/apply.php?coupon=no";
          $('#coupon_block').hide(); 
          
          $('#stripe_script_container').show();
         }
      });


      $(document).on("click", '#apply_coupon', function(){
        
       if($('#coupon1').val() != '' || $('#coupon2').val() != '') {
        //setNewCost($('#coupon1').val(), $('#coupon2').val());

       }
       //
      else alert('Enter at least one Coupon.');

      });      

      //console.log(doctorVerifiedParams.email);

      //custom Checkout integration
      var handler = StripeCheckout.configure({
          key: doctorVerifiedParams.publishable_key,
          image: '/img/documentation/checkout/marketplace.png',
          locale: 'auto',
          token: function(token) {
            // You can access the token ID with `token.id`.
            // Get the token ID to your server-side code for use.

            var token = token.id;

            console.log(token);

            // Insert the token ID into the form so it gets submitted to the server:
            jQuery('form').append(jQuery('<input type="hidden" name="stripeToken">').val(token));            
          }
        });

        $('#customButton').on('click', function(e) {
          // Open Checkout with further options:
          handler.open({
            name: 'Doctor Certified&trade;',
            description: 'One Time Setup Fee - $99.95',
            amount: 9995,
            email: $( "#txtEmailID" ).val()
          });
          e.preventDefault();
        });

        // Close Checkout on page navigation:
        $(window).on('popstate', function() {
          handler.close();
        });

    });


    //MEMBER AREA
    jQuery( document ).on( 'click', '#btnSaveDomain', function() {
    //jQuery( '#domainForm' ).on( 'submit', '#btnSaveDomain', function() {    

    jQuery("#display-form-result").html('');

    if ( jQuery.trim(jQuery("#website1").val()) != '' || 
       jQuery.trim(jQuery("#website2").val()) != '' || 
       jQuery.trim(jQuery("#website3").val()) != '' || 
       jQuery.trim(jQuery("#website4").val()) != '' || 
       jQuery.trim(jQuery("#website5").val()) != '' ) {
     
      if( (jQuery.trim(jQuery("#website1").val()) != '' && isValidDomain(jQuery("#website1").val())) || 
        (jQuery.trim(jQuery("#website2").val()) != '' && isValidDomain(jQuery("#website2").val())) || 
        (jQuery.trim(jQuery("#website3").val()) != '' && isValidDomain(jQuery("#website3").val())) ||
        (jQuery.trim(jQuery("#website4").val()) != '' && isValidDomain(jQuery("#website4").val())) ||
        (jQuery.trim(jQuery("#website5").val()) != '' && isValidDomain(jQuery("#website5").val())) ) {

        jQuery.ajax({
          url : doctorVerifiedParams.ajax_url,
          type : 'POST',
          data : {
            'action' : 'doctor_verified_send_mail',
            'website1' : isValidDomain(jQuery("#website1").val()) ? jQuery("#website1").val() : '',
            'website2' : isValidDomain(jQuery("#website2").val()) ? jQuery("#website2").val() : '',
            'website3' : isValidDomain(jQuery("#website3").val()) ? jQuery("#website3").val() : '',
            'website4' : isValidDomain(jQuery("#website4").val()) ? jQuery("#website4").val() : '',
            'website5' : isValidDomain(jQuery("#website5").val()) ? jQuery("#website5").val() : ''
          },
          //data:$("#domainForm").serialize(),
          success : function( data ) {
            //console.log(data);
            $("#display-form-result").html(data);

          },
          error:function (){}
        });       



      } else {

        $('#display-form-result').html('Domain should be valid.');  

      }

    } else {

      $('#display-form-result').html('At least one domain is required.');  

    }

    })   


    function isValidDomain(value){
     //var regex = /(.*?)[^w{3}.]([a-zA-Z0-9]([a-zA-Z0-9-]{0,65}[a-zA-Z0-9])?.)+[a-zA-Z]{2,6}/igm;
     
     var regex = /^(?!:\/\/)([a-zA-Z0-9-]+\.){0,5}[a-zA-Z0-9-][a-zA-Z0-9-]+\.[a-zA-Z]{2,64}?$/gi;

     if(regex.test(value)){
      return true;   
     }
     else return false;
    }





    jQuery(function($) {
        jQuery('#invoiceTable').DataTable();
    } );


})( jQuery );

