<?php
function doctor_verified_registration_form() {
	ob_start();
	if(isset($_GET['payment']) && $_GET['payment'] == 'paid') { ?>

		<h3>Step 3</h3>
		<fieldset>
		    <legend>Step 3</legend>

		    <p class="application-thanks-page-text"> Thanks for applying for a Doctor Certified&trade; seal. 
		    You will receive a confirmation receipt shortly via email.</p><br>
		    <div class="receipt-box">
		    <p class="receipt-header">Order Summary </p> <br>
		    <div class="receipt-tables-container">
		    <div class="receipt-top-price-background">
		        <table class="pricing-table">
		            <tr>
			            <td class="pricing-td-1">
			            	<p class="receipt-setup-fee"> One-Time Setup Fee</p>
		            	</td>
			            <td>
				            <p class="receipt-pricing-numbers">
							99.95 </p>
			            </td>
		            </tr>
		        </table>
		    <hr class="receipt-total-hr">
		    </div>
		    <div class="receipt-total-price-background">
		    <table class="pricing-table">
		        <tr>
		            <td class="pricing-td-1">
			            <p class="receipt-total-charge"> Total Charge Today </p>
			            </td>
		            <td>
			            <p class="receipt-total-charge-numbers">
						99.95</p>
		            </td>
		        </tr>
		    </table>
		    </div>
		    </div>
		    <br>
		    <p class="receipt-text"><b>A monthly service fee of $49.95 </b> will be charged to your account every month.<br><br>
		    The first charge will occur once your application has been approved. </p>
		    </div>
		    <br><br>
		    <p class="application-thanks-page-text"> It typically takes 2 - 4 days for the doctor to review your website. Once your website passes the review process we will send you a confirmation email with instructions on how to upload your Doctor Certified&trade; seal and certificate to your website. </p><br>
		    <p class="application-thanks-page-text"> You will also be able to access your seal and change your billing information by logging in to our <a href="#" class="faq-link" > website</a>. </p><br>
		    <p class="application-thanks-page-text"> If your website does not pass the initial review we will work with you to help get your website accepted, at no extra charge. </p>
		    <br><br>
		</fieldset>

<?php 
	} else {

?>
	<form id="applyform" action="" method="POST">
		<div id="message"></div>
	    <h3>Step 1</h3>
	    <fieldset>
	        <legend>Step 1</legend>
			<p>(*) Required</p>    

			<label class="label-style"><b>Domain Name *</b></label><br>
			<input type="text" name="txtDomain" id="txtDomain" maxlength="500" class="input-style" value="" />
			<p class="password-reminder">Enter the domain name where you would like the seal to be displayed.  </p>

			<label class="label-style"><b>Enter your Email *</b></label> <br>
			<input type="text" name="txtEmailID" id="txtEmailID"   maxlength="500" class=" input-style" value="test@example.com" >
			<p class="password-reminder">This will be used as your username as well as for correspondance.  </p>	

			<label class="label-style"><b>Choose a Password *</b></label><br> 
			<input type="password" name="txtNewPassword" id="txtNewPassword"  maxlength="25" class="input-style" value="123456"></input>
			<p class="password-reminder"> Password must be atleast six characters. </p>

			<label class="label-style"><b>Language *</b></label><br> 
			<select name="textLanguage" id="textLanguage" class="input-style"><option value="en" selected="selected">English (United States)</option><option value="ary">العربية المغربية</option><option value="ar">العربية</option><option value="az">Azərbaycan dili</option><option value="azb">گؤنئی آذربایجان</option><option value="bg_BG">Български</option><option value="bn_BD">বাংলা</option><option value="bs_BA">Bosanski</option><option value="ca">Català</option><option value="ceb">Cebuano</option><option value="cs_CZ">Čeština&lrm;</option><option value="cy">Cymraeg</option><option value="da_DK">Dansk</option><option value="de_CH">Deutsch (Schweiz)</option><option value="de_CH_informal">Deutsch (Schweiz, Du)</option><option value="de_DE">Deutsch</option><option value="de_DE_formal">Deutsch (Sie)</option><option value="el">Ελληνικά</option><option value="en_GB">English (UK)</option><option value="en_ZA">English (South Africa)</option><option value="en_NZ">English (New Zealand)</option><option value="en_CA">English (Canada)</option><option value="en_AU">English (Australia)</option><option value="eo">Esperanto</option><option value="es_VE">Español de Venezuela</option><option value="es_MX">Español de México</option><option value="es_ES">Español</option><option value="es_CO">Español de Colombia</option><option value="es_CL">Español de Chile</option><option value="es_AR">Español de Argentina</option><option value="es_GT">Español de Guatemala</option><option value="es_PE">Español de Perú</option><option value="et">Eesti</option><option value="eu">Euskara</option><option value="fa_IR">فارسی</option><option value="fi">Suomi</option><option value="fr_BE">Français de Belgique</option><option value="fr_CA">Français du Canada</option><option value="fr_FR">Français</option><option value="gd">Gàidhlig</option><option value="gl_ES">Galego</option><option value="haz">هزاره گی</option><option value="he_IL">עִבְרִית</option><option value="hi_IN">हिन्दी</option><option value="hr">Hrvatski</option><option value="hu_HU">Magyar</option><option value="hy">Հայերեն</option><option value="id_ID">Bahasa Indonesia</option><option value="is_IS">Íslenska</option><option value="it_IT">Italiano</option><option value="ja">日本語</option><option value="ka_GE">ქართული</option><option value="ko_KR">한국어</option><option value="lt_LT">Lietuvių kalba</option><option value="mk_MK">Македонски јазик</option><option value="mr">मराठी</option><option value="ms_MY">Bahasa Melayu</option><option value="my_MM">ဗမာစာ</option><option value="nb_NO">Norsk bokmål</option><option value="nl_NL">Nederlands</option><option value="nl_NL_formal">Nederlands (Formeel)</option><option value="nn_NO">Norsk nynorsk</option><option value="oci">Occitan</option><option value="pl_PL">Polski</option><option value="ps">پښتو</option><option value="pt_PT">Português</option><option value="pt_BR">Português do Brasil</option><option value="ro_RO">Română</option><option value="ru_RU">Русский</option><option value="sk_SK">Slovenčina</option><option value="sl_SI">Slovenščina</option><option value="sq">Shqip</option><option value="sr_RS">Српски језик</option><option value="sv_SE">Svenska</option><option value="th">ไทย</option><option value="tl">Tagalog</option><option value="tr_TR">Türkçe</option><option value="ug_CN">Uyƣurqə</option><option value="uk">Українська</option><option value="vi">Tiếng Việt</option><option value="zh_CN">简体中文</option><option value="zh_TW">繁體中文</option></select>			
			<br><br> 

			<label class="label-style-phone"><b>Phone Number </b> <span class="text-optional">(Optional)</span></label><br> 
			<input type="text" name="textTelephone" id="textTelephone"  size="26" maxlength="25" class="input-style-phone" value="" ></input>
			<p class="phone-number-reminder"> If we need to contact you about your application. </p>

	    </fieldset>
	 
	    <h3>Step 2</h3>
	    <fieldset>
	        <legend>Step 2</legend>
			<p>(*) Required</p>  	 

			<div class="pricing-background">
				<table class="pricing-table">
				<tr>
					<td class="pricing-td-1">
					<p class="individual-fees1"> One-Time Setup Fee</p>
					</td>
					<td>
					<p class="pricing-numbers" id="setup_price">$99.95 </p>
					</td>
				</tr>
				<tr>
					<td class="pricing-td-1">
					<p class="individual-fees"> Monthly Service Fee </p>
					</td>
					<td>
					<p class="pricing-numbers" id="monthly_cost"><span>$49.95</span> <span class="asterisk">* </span> </p>
					</td>
				</tr>
				</table>
				<hr class="total-hr">
				</div>
				<div class="total-charge-background">
				<table class="pricing-table">
				<tr>
					<td class="pricing-td-1">
					<p class="total-charge"> Total Charge Today </p>
					</td>
					<td>
					<p class="total-charge-numbers" id="total_setup_cost">$99.95</p>
					</td>
				</tr>
				</table>
			</div>
			<br>
			<p class="application2-text"><span class="asterisk">* </span>Your first monthly charge will be billed once your certificate is issued.<br>
			&nbsp;&nbsp;&nbsp;&nbsp;You may cancel at any time. </p> 

			<input type="hidden" name="amount" id="amount" class=" input-style" value="99.95" >
			<br>
			<input name="save" id="btnSave" type="button" value="Continue"  class="continue-button btn-70-l open2"  style="display: none" />               
			
			<div id="stripe_script_container" style="float:left;display:"> 
				<!--script src="/web/20160430033815js_/https://checkout.stripe.com/checkout.js" class="stripe-button" 
				data-key="pk_live_V6PISHjBPsBnhRRuM2KQGCUv" 
				data-amount="9995" data-name="Doctor Certified&trade;" 
				data-description="One Time Setup Fee - $99.95 " data-email="" 
				data-image="images/doc-stripe.png" 
				data-allow-remember-me="false">
				</script-->
				<button id="customButton">Purchase</button>
			</div> 

			<br clear="all">
			<br>   
			<label class="label-style"><b>Do you have a Coupon?</b><!--<input type="checkbox" name="coupon" id="coupon" value="1">--></label>
			Yes<input type="radio" value="1" name="coupon" id="yes_coupon">&nbsp; 
			No<input type="radio" value="1" name="coupon" id="no_coupon"> 

			<div style="display:none" id="coupon_block">
				<label class="label-style"><b>Enter your Coupon</b></label> <br>
				<input type="text" name="coupon1" id="coupon1"  class=" input-style"  placeholder="One-Time Setup"><br><br>
				<input type="text" name="coupon2" id="coupon2"  class=" input-style"  placeholder="Monthly Service"><br>
				<!--button class="btn btn-warning  continue-button btn-70-l" id="apply_coupon" type="button"> Apply</button--> 
			</div>

	    </fieldset>
	 
	    <!--h3>Step 3</h3>
	    <fieldset>
	        <legend>Step 3</legend>

            <p class="application-thanks-page-text"> Thanks for applying for a Doctor Certified&trade; seal. 
            You will receive a confirmation receipt shortly via email.</p><br>
            <div class="receipt-box">
            <p class="receipt-header">Order Summary </p> <br>
            <div class="receipt-tables-container">
            <div class="receipt-top-price-background">
	            <table class="pricing-table">
		            <tr>
			            <td class="pricing-td-1">
			            	<p class="receipt-setup-fee"> One-Time Setup Fee</p>
		            	</td>
			            <td>
				            <p class="receipt-pricing-numbers">
							99.95 </p>
			            </td>
		            </tr>
	            </table>
            <hr class="receipt-total-hr">
            </div>
            <div class="receipt-total-price-background">
            <table class="pricing-table">
	            <tr>
		            <td class="pricing-td-1">
			            <p class="receipt-total-charge"> Total Charge Today </p>
			            </td>
		            <td>
			            <p class="receipt-total-charge-numbers">
						99.95</p>
		            </td>
	            </tr>
            </table>
            </div>
            </div>
            <br>
            <p class="receipt-text"><b>A monthly service fee of $49.95 </b> will be charged to your account every month.<br><br>
            The first charge will occur once your application has been approved. </p>
            </div>
            <br><br>
            <p class="application-thanks-page-text"> It typically takes 2 - 4 days for the doctor to review your website. Once your website passes the review process we will send you a confirmation email with instructions on how to upload your Doctor Certified&trade; seal and certificate to your website. </p><br>
            <p class="application-thanks-page-text"> You will also be able to access your seal and change your billing information by logging in to our <a href="/web/20160430033815/https://www.doctor-certified.com/login.php" class="faq-link" > website</a>. </p><br>
            <p class="application-thanks-page-text"> If your website does not pass the initial review we will work with you to help get your website accepted, at no extra charge. </p>
            <br><br>
	    </fieldset-->

	    <input type="hidden" name="action" value="doctor-verified-stripe"/>
		<input type="hidden" name="redirect" value="<?php echo get_permalink(); ?>"/>
		<input type="hidden" name="doctor_verified_stripe_nonce" value="<?php echo wp_create_nonce('doctor-verified-stripe-nonce'); ?>"/>

	</form>

 
<?php
	}
	return ob_get_clean();
}
add_shortcode('doctor_verified_registration_form', 'doctor_verified_registration_form');



// YOUR WEB SEAL
function doctor_verified_web_seal_html_table() {

	$plugin_img_url = plugin_dir_url( __FILE__ ).'img/';
	$user_ID = get_current_user_id();
	$user_data = get_userdata($user_ID);
	$user_meta = get_user_meta($user_ID, 'wp_optimizemember_custom_fields');

	//$meta_arr['user_domain_0'] = ( isset($meta_arr['user_domain_0']) ? $meta_arr['user_domain_0'] : '' ); 

	//$check_web_seal = doctor_verified_check_domain($meta_arr['user_domain_0']);


	//echo 'There is a record in the database table (web_seals)';
	$web_seals = doctor_verified_web_seal_html_table_repeater_result();

	$output = '';

	//if( !current_user_can('administrator') && current_user_can('access_optimizemember_level1')) {



		$output = '<table width="100%" border="1">';
		$output .= '<tr style="color:#ffffff; background-color:#7296da; font-weight:bold; font-size:16px;">';
		$output .= '<th scope="col" style="padding-top:5px; padding-bottom:5px;">Status</th>';
		$output .= '<th scope="col" style="padding-top:5px; padding-bottom:5px;">Domain</th>';
		$output .= '<th scope="col" style="padding-top:5px; padding-bottom:5px;">Issued On</th>';
		$output .= '<th scope="col" style="padding-top:5px; padding-bottom:5px;">Seal Type</th>';
		$output .= '<th scope="col" style="padding-top:5px; padding-bottom:5px;">Code</th>';
		$output .= '<th scope="col" style="padding-top:5px; padding-bottom:5px;">Seal</th>';
		$output .= '</tr>';		



		if( is_array( $web_seals ) && count( $web_seals ) > 0 ) {
			foreach($web_seals as $web_seal) {
				
				$output .= '<tr>';
				$output .= '<td align="center" valign="top" style="padding-top:5px; padding-bottom:5px;">'. ucwords($web_seal->seal_status). '</td>';
				$output .= '<td align="center" valign="top" style="padding-top:5px; padding-bottom:5px;">'. $web_seal->seal_domain. '</td>';
				$output .= '<td align="center" valign="top" style="padding-top:5px; padding-bottom:5px;">'. date('m-d-Y', strtotime($web_seal->seal_issued_on)). '</td>';  	
				$output .= '<td align="center" valign="top" style="padding-top:5px; padding-bottom:5px;">'. ucwords($web_seal->seal_type) . '</td>';

				$output .= '<td align="center" valign="top" style="padding-top:5px; padding-bottom:5px;"><a href="http://puremaca.net/reviewsite5/code/?domain_id='.$web_seal->id.'" class=""> Get HTML Code</a></td>';
				$output .= '<td align="center" valign="top" style="padding-top:5px; padding-bottom:5px;">';
				$output .= '<div class="web_seal'.$web_seal->id.'" seal_type="version5"></div>';
				//$output .= "<script>var WebSeal{$web_seal->id} = new getWebSeal('{$web_seal->user_id}_{$web_seal->id}', 'version5');</script>";
				//$output .= var_dump(doctor_verified_web_seal_get_seal_domain_by_domain_id($web_seal->seal_domain));
				//$output .= "<script>alert('test');</script>";
				$output .= '</td>';				
				$output .= '</tr>';

				$output .= "<script>var WebSeal{$web_seal->id} = new getWebSeal('{$web_seal->user_id}_{$web_seal->id}', 'web_seal{$web_seal->id}');</script>";				

			}
		}


	//}

	$output .= '</table>';

	return $output;
}


function doctor_verified_web_seal_html_table_output() {
    ob_start();
    echo doctor_verified_web_seal_html_table();
    return ob_get_clean();
}


add_shortcode('doctor_verified_web_seal_html_table_repeater', 'doctor_verified_web_seal_html_table_output');


function doctor_verified_web_seal_enqueue_scripts() {

	wp_register_script( 'doctor-verified-web-seal-script', plugins_url( '/js/doctor-verified-web-seal.js' , __FILE__), array( 'jquery' ), '', false );
    wp_enqueue_script( 'doctor-verified-web-seal-script');

}

add_action( 'wp_enqueue_scripts', 'doctor_verified_web_seal_enqueue_scripts' );



function doctor_verified_html_form() {

	$output = '';

	//if(isset($_GET['domain']) && $_GET['domain'] == 1) {

	//} else {
	//if( !current_user_can('administrator') && current_user_can('access_optimizemember_level1')) {

		$output = '<div id="display-form-result"></div>';
		//$output .= '<form id="domainForm" name="domainForm" action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post" enctype="multipart/form-data">';
		//$output .= '<form id="domainForm" name="domainForm" action="" method="post" enctype="multipart/form-data">';
		$output .= '<form id="domainForm" name="domainForm" action="" method="post">';		
		$output .= '<div class="application-inner">';
		$output .= '<label class="label-style-domain">Domain 1:</label>';
		$output .= '<input type="text" name="website1" id="website1" class="input-style domain-input-spacing" value="' . ( isset( $_POST["website1"] ) ? esc_attr( $_POST["website1"] ) : '' ) . '">';
		$output .= '<br>';
		$output .= '<label class="label-style-domain">Domain 2:</label>';
		$output .= '<input type="text" name="website2" id="website2" class="input-style domain-input-spacing" value="' . ( isset( $_POST["website2"] ) ? esc_attr( $_POST["website2"] ) : '' ) . '">';
		$output .= '<br>';
		$output .= '<label class="label-style-domain">Domain 3:</label>';
		$output .= '<input type="text" name="website3" id="website3" class="input-style domain-input-spacing" value="' . ( isset( $_POST["website3"] ) ? esc_attr( $_POST["website3"] ) : '' ) . '">';
		$output .= '<br>';
		$output .= '<label class="label-style-domain">Domain 4:</label>';
		$output .= '<input type="text" name="website4" id="website4" class="input-style domain-input-spacing" value="' . ( isset( $_POST["website4"] ) ? esc_attr( $_POST["website4"] ) : '' ) . '">';
		$output .= '<br>';
		$output .= '<label class="label-style-domain">Domain 5:</label>';
		$output .= '<input type="text" name="website5" id="website5" class="input-style domain-input-spacing" value="' . ( isset( $_POST["website5"] ) ? esc_attr( $_POST["website5"] ) : '' ) . '">';
		$output .= '<br><br>';
		$output .= '<input name="save" id="btnSaveDomain" type="button" value="Continue" class="continue-button btn-70-l">';
		//$output .= '<input type="submit" name="save" id="btnSaveDomain" value="Continue" class="continue-button btn-70-l">';
		$output .= '</div>';

	    $output .= '<input type="hidden" name="action" value="doctor-verified-stripe"/>';
		$output .= '<input type="hidden" name="redirect" value="'. get_permalink().'"/>';
		$output .= '<input type="hidden" name="doctor_verified_additional_domain_nonce" value="'. wp_create_nonce('doctor-verified-additional-domain-nonce').'"/>';
		$output .= '</form>';
	//}
	//}
	
	return $output;

}

function doctor_verified_html_form_output() {
    ob_start();
    doctor_verified_send_mail();
    echo doctor_verified_html_form();
    return ob_get_clean();
}


add_shortcode('apply_for_additional_certificates_form', 'doctor_verified_html_form_output');



//https://stripe.com/docs/recipes/updating-customer-cards
//http://stackoverflow.com/questions/29753923/stripe-update-customer-default-card-php
//http://stackoverflow.com/questions/31627961/stripe-change-credit-card-number
//https://stripe.com/docs/api/php#create_charge
//https://stripe.com/docs/charges
function doctor_verified_card_update(){

	$plugin_img_url = plugin_dir_url( __FILE__ ).'img/';
	$user_ID = get_current_user_id();
	$user_data = get_userdata($user_ID);
	$customer_id = get_user_meta($user_ID, 'wp_optimizemember_subscr_cid');

	$user_email = isset($user_data->user_email) ? $user_data->user_email : '';

	/*if (!class_exists('Stripe')) {
		require_once ABSPATH.'wp-content/plugins/optimizeMember/optimizeMember-pro/includes/classes/gateways/stripe/stripe-sdk/lib/Stripe.php';
		//C:\wamp\www\wpdoctorsverified\wp-content\plugins\optimizeMember\optimizeMember-pro\includes\classes\gateways\stripe\stripe-sdk\lib\Stripe

		Stripe::setApiKey('sk_test_XqQdQBT9MaHLUBaRnNt2SXbl');
		Stripe::setApiVersion('2015-02-18');
	}	

    //$charges = Stripe_Charge::all(array("customer" => $customer_id[0], "limit" => 10));	

	//$invoice_items = Stripe_InvoiceItem::all(array("customer" => $customer_id[0], "limit" => 10));

	$invoices = Stripe_Invoice::all(array("customer" => $customer_id[0], "limit" => 10));

    echo 'COUNT'.count($invoices["data"]);
    echo "<pre>";
    //echo print_r($invoices["data"]);	
    echo print_r($invoices["data"][0]->lines["data"]);
    echo print_r($invoices["data"][1]->lines["data"]);
    //echo print_r($invoices["data"][2]);
    echo "<pre>";
    return;*/
    
    $output = '';

	$output = '<form id="cccard-info-form-update" novalidate autocomplete="on" action="" method="POST">';
	$output .= '<p class="validation"></p>';
	$output .= '<div class="form-group">';
	$output .= '<label for="cc-number" class="control-label">Card number formatting <small class="text-muted">[<span class="cc-brand"></span>]</small></label>';
	$output .= '<input id="cc-number" type="tel" class="input-lg form-control cc-number" autocomplete="cc-number" placeholder="•••• •••• •••• ••••" required>';
	$output .= '</div>';

	$output .= '<div class="form-group">';
	$output .= '<label for="cc-exp" class="control-label">Card expiry formatting</label>';
	$output .= '<input id="cc-exp" type="tel" class="input-lg form-control cc-exp" autocomplete="cc-exp" placeholder="•• / ••" required>';
	$output .= '</div>';

	$output .= '<div class="form-group">';
	$output .= '<label for="cc-cvc" class="control-label">Card CVC formatting</label>';
	$output .= '<input id="cc-cvc" type="tel" class="input-lg form-control cc-cvc" autocomplete="off" placeholder="•••" required>';
	$output .= '</div>';

	$output .= '<!--div class="form-group">';
	$output .= '<label for="numeric" class="control-label">Restrict numeric</label>';
	$output .= '<input id="numeric" type="tel" class="input-lg form-control" data-numeric>';
	$output .= '</div-->';

	$output .= '<input type="hidden" name="email" value="'.$user_email.'">';

	$output .= '<button type="submit" class="submit btn btn-lg btn-primary">Submit</button>';
	$output .= '</form>';

	/*$output .= '<table id="invoiceTable" class="display" cellspacing="0" width="100%">';
	$output .= '<thead>';
	$output .= '<tr>';
	$output .= '<th>Date</th>';
	$output .= '<th>Payment For</th>';
	$output .= '<th>Amount</th>';            
	$output .= '</tr>';
	$output .= '</thead>';
	$output .= '<tbody>';

	for($i = 0; $i < count($invoices["data"]); $i++) {

	//$timestamp = $invoices["data"][$i]->created;
	//$datetimeFormat = 'Y-m-d H:i:s';

	//$date = new \DateTime();
	//$date->setTimestamp($timestamp);
	//$created = $date->format($datetimeFormat);

		$output .= '<tr>';
		$output .= '<td class="align-row-center">'.$invoices["data"][$i]->lines["data"]->period->start.' - '.$invoices["data"][$i]->lines["data"]->period->end.'</td>'; //May 28, 2016-Jun 28, 2016
		$output .= '<td class="align-row-center">'.$invoices["data"][$i]->lines["data"]->description.'</td>'; //Doctor Certified $29.95 monthly service fee
		$output .= '<td class="align-row-center">'.$invoices["data"][$i]->lines["data"]->amount.'</td>'; //$29.95 
		$output .= '</tr>';
	}

	$output .= '</tbody>';
	$output .= '</table>';*/
	    
	/*echo '<ul>';
	echo '<li>';
	echo 'Date: '.$charges["data"][$i]->created;
	echo 'Payment For: '.$charges["data"][$i]->description;
	echo 'Amount: '.$charges["data"][$i]->amount;
	echo '</li>';
	echo '</ul>';*/

	return $output;

} 

function doctor_verified_card_update_output() {
    ob_start();
    echo doctor_verified_card_update();
    return ob_get_clean();
}

add_shortcode('doctor_verified_card_update', 'doctor_verified_card_update_output');