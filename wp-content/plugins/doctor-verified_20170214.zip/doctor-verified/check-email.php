<?php
header('Content-Type: application/json');
//$email= $_REQUEST['txtEmailID'];
$path = $_SERVER['DOCUMENT_ROOT'];

include_once $path . '/wp-config.php';
include_once $path . '/wp-load.php';
include_once $path . '/wp-includes/wp-db.php';
include_once $path . '/wp-includes/pluggable.php';
include_once $path . '/wp/wp-includes/user.php';
global $wpdb;

//$email_exists = $wpdb->get_row('SELECT COUNT(*) as count from reg_form_new WHERE email = "'.$email.'"');

//if ( $email_exists->count == 0 ) { echo 'true'; } else { echo 'false'; }


if(email_exists($_REQUEST['txtEmailID'])){
    $response = json_encode('Already registered');
}
else{
    $response = json_encode('true');
}
echo $response;
exit; 