<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit("Do not access this file directly.");
?>

<div class="ws-plugin--optimizemember-s-badge">
<a href="http://www.optimizepress.com/" onclick="window.open('http://www.optimizepress.com/s-badges/s-details.php?v=%%v%%&amp;site_url=%%site_url%%%%no_cache%%%%display_on_failure%%', '_popup', 'width=752,height=702,left='+((screen.width/2)-(752/2))+',screenX='+((screen.width/2)-(752/2))+',top='+((screen.height/2)-(702/2))+',screenY='+((screen.height/2)-(702/2))+',location=0,menubar=0,toolbar=0,scrollbars=0,resizable=1'); return false;" title="optimizeMember&reg;"><img src="//www.optimizepress.com/s-badges/s-badge.php?v=%%v%%&amp;site_url=%%site_url%%%%no_cache%%%%display_on_failure%%" style="border:0;" alt="optimizeMember&reg;" title="<?php echo esc_attr (_x ("optimizeMember&reg; ( Security for WordPress&reg; )", "s2member-front", "s2member")); ?>" /></a>
</div>