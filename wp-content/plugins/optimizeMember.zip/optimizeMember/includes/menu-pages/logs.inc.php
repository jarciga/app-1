<?php
/**
* Menu page for the OptimizeMember plugin (Logs page).
*/
if(!defined('WPINC'))
	exit("Do not access this file directly.");

if(!class_exists("c_ws_plugin__optimizemember_menu_page_logs"))
	{
		/**
		* Menu page for the optimizeMember plugin (Logs page).
		*
		* @package optimizeMember\Menu_Pages
		* @since 110531
		*/
		class c_ws_plugin__optimizemember_menu_page_logs
			{
				public function __construct()
					{
                        echo '<div class="wrap ws-menu-page op-bsw-wizard op-bsw-content">' . "\n";
                        /**/
                        echo '<div class="op-bsw-header">';
                        echo '<div class="op-logo"><img src="' . $GLOBALS["WS_PLUGIN__"]["optimizemember"]["c"]["dir_url"]."/images/" . 'logo-optimizepress.png" alt="OptimizePress" height="50" class="animated flipInY"></div>';
                        echo '</div>';
                        echo '<div class="op-bsw-main-content">';

						echo '<h2>Log Files</h2>'."\n";

						echo '<table class="ws-menu-page-table">'."\n";
						echo '<tbody class="ws-menu-page-table-tbody">'."\n";
						echo '<tr class="ws-menu-page-table-tr">'."\n";
						echo '<td class="ws-menu-page-table-l">'."\n";

						do_action("ws_plugin__optimizemember_during_logs_page_before_left_sections", get_defined_vars());

						/*if (apply_filters("ws_plugin__optimizemember_during_logs_page_during_left_sections_display_help", true, get_defined_vars ()))
						{
							do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_before_help", get_defined_vars ());

							echo '<div class="ws-menu-page-group" title="Getting Help">' . "\n";

							echo '<div class="ws-menu-page-section ws-plugin--optimizemember-help">' . "\n";
							echo '<h3>Getting Help w/ optimizeMember (Troubleshooting)</h3>' . "\n";
							echo '<p>optimizeMember is pretty easy to setup and install initially. Most of the official documentation is right here in your Dashboard (i.e. there is a lot of inline documentation built into the software). That being said, it CAN take some time to master everything there is to know about optimizeMember\'s advanced features. If you need assistance with optimizeMember, please search the <a href="http://www.s2member.com/kb/" target="_blank" rel="external">optimizeMember Knowledge Base</a>, <a href="http://www.s2member.com/videos/" target="_blank" rel="external">Video Tutorials</a>, <a href="http://www.s2member.com/forums/" target="_blank" rel="external">Forums</a> and <a href="http://www.s2member.com/codex/" target="_blank" rel="external">Codex</a>. If you are planning to do something creative with optimizeMember, you might want to <a href="http://jobs.wordpress.net" target="_blank" rel="external">hire a freelance developer</a> to assist you.</p>' . "\n";
							echo '<p><strong>See also:</strong> <a href="http://www.s2member.com/kb/common-troubleshooting-tips/" target="_blank" rel="external">optimizeMember Troubleshooting Guide</a> (please read this first if you\'re having trouble).</p>'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							echo '<h3>Testing Server Compatibility</h3>'."\n";
							echo '<p>Please download the <a href="http://www.s2member.com/r/server-check-tool/">optimizeMember Server Scanner</a>. Unzip, upload via FTP; then open in a browser for a full report.</p>'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							echo '<h3>Troubleshooting Payment Gateway Integrations</h3>'."\n";
							echo '<p>Please use the optimizeMember Log Viewer (below). Log files can be very helpful.</p>'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							echo '<h3>Search optimizeMember KB Articles, Forums, Codex and more<em>!</em></h3>'."\n";
							echo '<form method="get" action="http://www.s2member.com/quick-s.php" target="_blank" onsubmit="if(this.q.value === \'enter search terms...\') this.q.value = \'\';">'."\n";
							echo '<p><input type="text" name="q" value="enter search terms..." style="width:60%;" onfocus="if(this.value === \'enter search terms...\') this.value = \'\';" onblur="if(this.value === \'\') this.value = \'enter search terms...\';" /> <input type="submit" value="Search" style="font-size:120%; font-weight:normal;" /></p>'."\n";
							echo '</form>'."\n";

							do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_during_help", get_defined_vars ());
							echo '</div>' . "\n";
							echo '</div>' . "\n";

							do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_after_help", get_defined_vars ());
						}*/

						if(apply_filters("ws_plugin__optimizemember_during_logs_page_during_left_sections_display_log_settings", true, get_defined_vars()))
							{
								do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_before_log_settings", get_defined_vars());

								echo '<div class="ws-menu-page-group" title="Logging Configuration">'."\n";
								echo '<div class="ws-menu-page-section ws-plugin--optimizemember-log-settings-section">'."\n";

								echo '<h3>Logging Configuration</h3>'."\n";

								echo '<div class="info">'."\n";
								echo '<p style="font-size:110%; margin-top:0;"><span>We HIGHLY recommend that you enable logging during your initial testing phase. Logs produce lots of useful details that can help in debugging. Logs can help you find issues in your configuration and/or problems that occur during processing. Enable logging here, and then view your log files below; in the optimizeMember Log Viewer.</span></p>'."\n";
								echo '<p style="font-size:110%; margin-bottom:0;"><span class="ws-menu-page-error">However, it is VERY IMPORTANT to disable logging once you go live. Log files may contain personally identifiable information, credit card numbers, secret API credentials, passwords and/or other sensitive information. We STRONGLY suggest that logging be disabled on a live site (for security reasons).</span></p>'."\n";
								echo '</div>'."\n";

//								echo '<div class="notice" style="margin-bottom:0;">'."\n";
//								echo '<p style="font-size:110%; margin-bottom:0;"><span>Regarding optimizeMember Security Badges. If debug logging is enabled, your site will NOT qualify for an optimizeMember Security Badge until you disable logging (and you must ALSO download, and then delete any existing log files). For further details, please see KB Article: <a href="http://www.s2member.com/kb/security-badges/" target="_blank" rel="external">optimizeMember Security Badges</a>.</span></p>'."\n";
//								echo '</div>'."\n";

								echo '<div class="ws-menu-page-hr"></div>'."\n";

								do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_during_log_settings", get_defined_vars());

								echo '<form method="post" name="ws_plugin__optimizemember_options_form" id="ws-plugin--optimizemember-options-form">' . "\n";
								echo '<input type="hidden" name="ws_plugin__optimizemember_options_save" id="ws-plugin--optimizemember-options-save" value="' . esc_attr (wp_create_nonce ("ws-plugin--optimizemember-options-save")) . '" />' . "\n";

								echo '<table class="form-table">' . "\n";
								echo '<tbody>' . "\n";
								echo '<tr>' . "\n";

								echo '<th>'."\n";
								echo '<label for="ws-plugin--optimizemember-gateway-debug-logs">'."\n";
								echo 'Enable Logging Routines?'."\n";
								echo '</label>'."\n";
								echo '</th>'."\n";

								echo '</tr>'."\n";
								echo '<tr>'."\n";

								echo '<td>'."\n";
								echo '<input type="radio" name="ws_plugin__optimizemember_gateway_debug_logs" id="ws-plugin--optimizemember-gateway-debug-logs-0" value="0"'.((!$GLOBALS["WS_PLUGIN__"]["optimizemember"]["o"]["gateway_debug_logs"]) ? ' checked="checked"' : '').' /> <label for="ws-plugin--optimizemember-gateway-debug-logs-0">No</label> &nbsp;&nbsp;&nbsp; <input type="radio" name="ws_plugin__optimizemember_gateway_debug_logs" id="ws-plugin--optimizemember-gateway-debug-logs-1" value="1"'.(($GLOBALS["WS_PLUGIN__"]["optimizemember"]["o"]["gateway_debug_logs"]) ? ' checked="checked"' : '').' /> <label for="ws-plugin--optimizemember-gateway-debug-logs-1">Yes, enable debugging w/ HTTP, API, IPN &amp; Return Page logging (and List Server API logs too).</label><br />'."\n";
								echo '<em>This enables logging overall. Includes optimizeMember HTTP, API, IPN and Return Page logging. Also logs any List Server integrations.</em><br />'."\n";
								echo '<em>* Use only for debugging. This should NEVER be enabled on a live site.<br />* The log files are stored here: <code>'.esc_html(c_ws_plugin__optimizemember_utils_dirs::doc_root_path($GLOBALS["WS_PLUGIN__"]["optimizemember"]["c"]["logs_dir"])).'</code></em>'."\n";
								echo '</td>'."\n";

								echo '</tr>'."\n";
								/*echo '<tr>' . "\n";

								echo '<th>'."\n";
								echo '<label for="ws-plugin--optimizemember-gateway-debug-logs-extensive">'."\n";
								echo 'Enable Additional Logging Routines?'."\n";
								echo '</label>'."\n";
								echo '</th>'."\n";

								echo '</tr>'."\n";
								echo '<tr>'."\n";

								echo '<td>'."\n";
								echo '<input type="radio" name="ws_plugin__optimizemember_gateway_debug_logs_extensive" id="ws-plugin--optimizemember-gateway-debug-logs-extensive-0" value="0"'.((!$GLOBALS["WS_PLUGIN__"]["optimizemember"]["o"]["gateway_debug_logs_extensive"]) ? ' checked="checked"' : '').' /> <label for="ws-plugin--optimizemember-gateway-debug-logs-extensive-0">No</label> &nbsp;&nbsp;&nbsp; <input type="radio" name="ws_plugin__optimizemember_gateway_debug_logs_extensive" id="ws-plugin--optimizemember-gateway-debug-logs-extensive-1" value="1"'.(($GLOBALS["WS_PLUGIN__"]["optimizemember"]["o"]["gateway_debug_logs_extensive"]) ? ' checked="checked"' : '').' /> <label for="ws-plugin--optimizemember-gateway-debug-logs-extensive-1">Yes, enable debugging w/ HTTP connection logging for ALL of WordPress.</label><br />'."\n";
								echo '<em>This enables HTTP connection logging for ALL of WordPress (quite extensive).<br />* Use only for debugging. This should NEVER be enabled on a live site.<br />* Creates the additional log file: <code>wp-http-api-debug.log</code></em>'."\n";
								echo '</td>'."\n";

								echo '</tr>'."\n";*/
								echo '</tbody>' . "\n";
								echo '</table>' . "\n";

								echo '<p class="submit" style="margin-top:20px;">'."\n";
								echo '<input type="submit" value="Update Logging Configuration" />'."\n";
								echo '</p>' . "\n";

								echo '</form>'."\n";

								echo '</div>'."\n";
								echo '</div>'."\n";

								do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_after_log_settings", get_defined_vars());
							}

						if(apply_filters("ws_plugin__optimizemember_during_logs_page_during_left_sections_display_logs", true, get_defined_vars()))
						{
							do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_before_logs", get_defined_vars());

							echo '<div class="ws-menu-page-group" title="Logs Viewer" default-state="open">'."\n";

							echo '<div class="ws-menu-page-section ws-plugin--optimizemember-logs-section">'."\n";
							echo '<h3>Debugging Tools/Tips &amp; Other Important Details (<a href="#" onclick="jQuery(\'div#ws-plugin--optimizemember-debugging-tips-details\').toggle(); return false;" class="ws-dotted-link">click here to toggle</a>)</h3>'."\n";

							echo '<div id="ws-plugin--optimizemember-debugging-tips-details" style="display:none;">'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							/*echo '<form method="post" onsubmit="if(!confirm(\'Archive all existing log files?\n\nAll of your current log files will be archived (e.g. they will simply be renamed with an ARCHIVED tag &amp; date in their file name); and new log files will be created automatically the next time optimizeMember logs something on your installation.\n\nPlease click OK to confirm this action.\')) return false;">'."\n";
							echo '<input type="hidden" name="ws_plugin__optimizemember_logs_archive_start_fresh" value="'.esc_attr(wp_create_nonce ("ws-plugin--optimizemember-logs-archive-start-fresh")).'" />'."\n";
							echo '<input type="submit" value="Archive All Current Log Files" class="ws-menu-page-right ws-plugin--optimizemember-archive-logs-start-fresh-button" style="font-size:110%; font-weight:normal; clear:right; min-width:200px;" />'."\n";
							echo '</form>'."\n";

							echo '<form method="post" onsubmit="if(!confirm(\'Delete all existing log files?\n\nThis will permanently delete ALL of your existing log files (including any archived log files).\n\nPlease click OK to confirm this action.\')) return false;">'."\n";
							echo '<input type="hidden" name="ws_plugin__optimizemember_logs_delete_start_fresh" value="'.esc_attr(wp_create_nonce ("ws-plugin--optimizemember-logs-delete-start-fresh")).'" />'."\n";
							echo '<input type="submit" value="Permanently Delete All Log Files" class="ws-menu-page-right ws-plugin--optimizemember-delete-logs-start-fresh-button" style="font-size:110%; font-weight:normal; clear:right; min-width:200px;" />'."\n";
							echo '</form>'."\n";

							echo '<form method="post">'."\n";
							echo '<input type="hidden" name="ws_plugin__optimizemember_logs_download_zip" value="'.esc_attr(wp_create_nonce ("ws-plugin--optimizemember-logs-download-zip")).'" />'."\n";
							echo '<input type="submit" value="Download All Log Files (Zip File)" class="ws-menu-page-right ws-plugin--optimizemember-logs-download-zip-button" style="font-size:110%; font-weight:normal; clear:right; min-width:200px;" />'."\n";
							echo '</form>'."\n";*/

							echo '<p><strong>Debugging Tips:</strong> &nbsp;&nbsp; It is normal to see a few errors in your log files. This is because optimizeMember logs ALL of its communication with Payment Gateways. Everything — not just successes. With that in mind, there will be some failures that optimizeMember expects (to a certain extent); and optimizeMember deals with these gracefully. What you\'re looking for here, are things that jump right out at you as being a major issue (e.g. when optimizeMember makes a point of providing details to you in a log entry about problems that should be corrected on your installation). Please read carefully.</p>'."\n";
							echo '<p><strong>Test Transaction Tips:</strong> &nbsp;&nbsp; Generally speaking, it is best to run test transactions for yourself. Be sure to run your final test transactions against a live Payment Gateway that is NOT in Sandbox/Test Mode (<a href="#" onclick="alert(\'While some Payment Gateways make it possible for you to run test transactions in Sandbox/Test Mode, these are NOT a reliable way to test optimizeMember.\n\nOften times (particularly with PayPal) Sandbox/Test mode behaves somewhat differently — often with buggy behavior. This can really create frustration for site owners. Therefore, it is always a good idea to run low dollar test transactions against a live Payment Gateway.\n\nAlso, please be sure that you are NOT logged in as an Administrator when running test transactions. For most test transactions, you will want to be completely logged out of your site before completing checkout (just a new Customer would be). If you are testing an upgrade or downgrade (where you DO need to be logged-in), please do NOT attempt this under an Administrative account. optimizeMember will NOT upgrade/downgrade Administrative accounts — for security purposes.\'); return false;">click here for details</a>). After running test transactions, please review the log file entries pertaining to your transaction. Does optimizeMember report any major issues? If so, please read through any details that optimizeMember provides in the log file.</p>'."\n";
							echo '<p><strong>OPM Core Processors:</strong> &nbsp;&nbsp; It is normal to have a <code>paypay-ipn.log</code> and/or a <code>paypay-rtn.log</code> file at all times. Ultimately, all Payment Gateway integrations supported by optimizeMember pass through it\'s core PayPal processors; even if you\'ve integrated with another Payment Gateway. If you are having trouble, and you don\'t find any errors in your Payment Gateway log files, please check the <code>paypay-ipn.log</code> and <code>paypay-rtn.log</code> files too. Regarding optimizeMember Pro Forms... If you\'ve integrated optimizeMember Pro Forms, you will NOT have a <code>paypay-rtn.log</code> file, because that particular processor is not used with Pro Form integrations. However, you will have a <code>paypay-ipn.log</code> file, and you will need to make a point of inspecting this file to ensure there were no post-processing issues.</p>'."\n";
							//echo '<p><strong>s2 HTTP API Logs:</strong> &nbsp;&nbsp; If optimizeMember is not behaving as expected, and you cannot find errors anywhere in your Payment Gateway log files (or with any core PayPal processors), please review your <code>s2-http-api-debug.log</code> file too. Look for any HTTP connections where optimizeMember is getting <code>403</code>, <code>404</code>, <code>503</code> errors from your server. This can sometimes happen due to <a href="http://www.s2member.com/kb/mod-security-random-503-403-errors/" target="_blank" rel="external">paranoid Mod Security configurations</a>, and it may require you to contact your hosting company for assistance.</p>'."\n";
							echo '<p style="font-style:italic;"><strong>Archived Log Files:</strong> &nbsp;&nbsp; All optimizeMember log files are stored here: <code>'.esc_html(c_ws_plugin__optimizemember_utils_dirs::doc_root_path($GLOBALS["WS_PLUGIN__"]["optimizemember"]["c"]["logs_dir"])).'</code>. Any log files that contain the word <code>ARCHIVED</code> in their name, are files that reached a size of more than 2MB, so optimizeMember archived them automatically to prevent any single log file from becoming too large. Archived log file names will also contain the date/time they were archived by optimizeMember. These archived log files typically contain much older (and possibly outdated) log entries.</p>'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							echo '<h3>optimizeMember Log File Descriptions (for ALL possible log file names)</h3>'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							echo '<ul class="ws-menu-page-li-margins">'."\n";
							foreach(c_ws_plugin__optimizemember_utils_logs::$log_file_descriptions as $_k => $_v)
								echo '<li style="font-family:\'Georgia\', serif;"><code><strong>'.esc_html(preg_replace('/^\/|\/$/', '', $_k)).'.log</strong></code> &nbsp;&nbsp; '.esc_html($_v["long"]).'</li>'."\n";
							unset($_k, $_v); // Housekeeping.
							echo '</ul>'."\n";

							echo '<div class="ws-menu-page-hr"></div>' . "\n";

							echo '</div>'."\n";

							do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_during_logs", get_defined_vars());

							$log_file_options = ""; // Initialize to an empty string.
							$view_log_file = (!empty($_POST["ws_plugin__optimizemember_log_file"])) ? esc_html($_POST["ws_plugin__optimizemember_log_file"]) : "";
							$logs_dir = $GLOBALS["WS_PLUGIN__"]["optimizemember"]["c"]["logs_dir"];

							if(is_dir($logs_dir)) // Do we have a logs directory on this installation?
							{
								$log_files = scandir($logs_dir); sort($log_files, SORT_STRING);

								$log_file_options .= '<optgroup label="Current Log Files">';
								foreach($log_files as $_log_file) // Build options for each current log file.
								{
									$_log_file_description = array("short" => "No description available.", "long" => "No description available.");

									foreach(c_ws_plugin__optimizemember_utils_logs::$log_file_descriptions as $_k => $_v)
										if(preg_match($_k, $_log_file))
										{
											$_log_file_description = $_v;
											break; // Stop here.
										}
									unset($_k, $_v); // Housekeeping.

									if(preg_match("/\.log$/", $_log_file) && stripos($_log_file, "-ARCHIVED-") === FALSE)
										$log_file_options .= '<option data-type="current" title="'.esc_attr($_log_file_description["long"]).'" value="'.esc_attr($_log_file).'"'.(($view_log_file === $_log_file) ? ' style="font-weight:bold;" selected="selected"' : '').'>'.esc_html($_log_file).' — '.esc_html($_log_file_description["short"]).'</option>';
								}
								unset($_log_file_description, $_log_file); // Housekeeping.
								$log_file_options .= '</optgroup>';

								if(stripos($log_file_options, '<option data-type="current"') === FALSE)
									$log_file_options .= '<option value="" disabled="disabled">— No current log files yet. —</option>';

								$log_file_options .= '<option value="" disabled="disabled"></option>';

								$log_file_options .= '<optgroup label="Archived Log Files">';
								foreach($log_files as $_log_file) // Build options for each ARCHIVED log file.
								{
									if(preg_match("/\.log$/", $_log_file) && stripos($_log_file, "-ARCHIVED-") !== FALSE)
										$log_file_options .= '<option data-type="archived" value="'.esc_attr($_log_file).'"'.(($view_log_file === $_log_file) ? ' style="font-weight:bold;" selected="selected"' : '').'>'.esc_html($_log_file).'</option>';
								}
								$log_file_options .= '</optgroup>';

								if(stripos($log_file_options, '<option data-type="archived"') === FALSE)
									$log_file_options .= '<option value="" disabled="disabled">— No log files archived yet. —</option>';
							}
							$log_file_options = '<option value="">— Choose a Log File to View —</option>'.
							                    '<option value="" disabled="disabled"></option>'.
							                    $log_file_options;

							echo '<form method="post" name="ws_plugin__optimizemember_log_viewer" id="ws-plugin--optimizemember-log-viewer">' . "\n";

							echo '<table class="form-table">' . "\n";
							echo '<tbody>' . "\n";
							echo '<tr>' . "\n";

							echo '<td style="width:80%;">' . "\n";
							echo '<select name="ws_plugin__optimizemember_log_file" id="ws-plugin--optimizemember-log-file">' . "\n";
							echo $log_file_options."\n";
							echo '</select>' . "\n";
							echo '</td>' . "\n";

							echo '<td style="width:20%; padding-left:5px;">' . "\n";
							echo '<input type="submit" value="View" style="font-size:120%; font-weight:normal;" />'."\n";
							echo '</td>' . "\n";

							echo '</tr>' . "\n";
							echo '</tbody>' . "\n";
							echo '</table>' . "\n";

							echo '<table class="form-table">' . "\n";
							echo '<tbody>' . "\n";
							echo '<tr>' . "\n";

							echo '<td>' . "\n";

							if($view_log_file && file_exists($logs_dir."/".$view_log_file) && filesize($logs_dir."/".$view_log_file))
							{
								$_log_file_description = array("short" => "", "long" => "");

								foreach(c_ws_plugin__optimizemember_utils_logs::$log_file_descriptions as $_k => $_v)
									if(preg_match($_k, $view_log_file))
									{
										$_log_file_description = $_v;
										break; // Stop here.
									}
								unset($_k, $_v); // Housekeeping.

								if(!empty($_log_file_description["long"])) // Do we have a description that we can display here?
									echo '<p style="clear:both; width:80%; font-family:\'Georgia\', serif; font-style:italic;"><strong>Description for <a href="'.esc_attr(add_query_arg(array("ws_plugin__optimizemember_download_log_file" => $view_log_file, "ws_plugin__optimizemember_download_log_file_v" => wp_create_nonce ("ws-plugin--optimizemember-download-log-file-v")))).'">'.esc_html($view_log_file).'</a></strong>: '.esc_html($_log_file_description["long"]).'</p>'."\n";
								unset($_log_file_description); // Just a little housekeeping here.

								echo '<p style="float:left; text-align:left;"><strong>Viewing:</strong> <a href="'.esc_attr(add_query_arg(array("ws_plugin__optimizemember_download_log_file" => $view_log_file, "ws_plugin__optimizemember_download_log_file_v" => wp_create_nonce ("ws-plugin--optimizemember-download-log-file-v")))).'">'.esc_html($view_log_file).'</a> (log entries oldest to newest)</p>'."\n";
								echo '<p style="float:right; text-align:right;">[ <a href="'.esc_attr(add_query_arg(array("ws_plugin__optimizemember_download_log_file" => $view_log_file, "ws_plugin__optimizemember_download_log_file_v" => wp_create_nonce ("ws-plugin--optimizemember-download-log-file-v")))).'"><strong>download file</strong></a> ]</p>'."\n";
								echo '<p style="margin-right:10px; float:right; text-align:right;"><a href="#" class="ws-plugin--optimizemember-log-file-viewport-toggle" style="text-decoration:none;">&#8659; expand viewport &#8659;</a></p>'."\n";

								echo '<textarea id="ws-plugin--optimizemember-log-file-viewer" rows="20" wrap="on" spellcheck="false" style="box-shadow:inset 0 0 5px rgba(0,0,0,0.5); background:#EEEEEE; color:#000000; overflow-y:scroll;" class="monospace">'.htmlspecialchars(file_get_contents($logs_dir."/".$view_log_file)).'</textarea>' . "\n";

								echo '<p style="float:left; text-align:left;"><strong>Viewing:</strong> <a href="'.esc_attr(add_query_arg(array("ws_plugin__optimizemember_download_log_file" => $view_log_file, "ws_plugin__optimizemember_download_log_file_v" => wp_create_nonce ("ws-plugin--optimizemember-download-log-file-v")))).'">'.esc_html($view_log_file).'</a> (log entries oldest to newest)</p>'."\n";
								echo '<p style="float:right; text-align:right;">[ <a href="'.esc_attr(add_query_arg(array("ws_plugin__optimizemember_download_log_file" => $view_log_file, "ws_plugin__optimizemember_download_log_file_v" => wp_create_nonce ("ws-plugin--optimizemember-download-log-file-v")))).'"><strong>download file</strong></a> ]</p>'."\n";
								echo '<p style="margin-right:10px; float:right; text-align:right;"><a href="#" class="ws-plugin--optimizemember-log-file-viewport-toggle" style="text-decoration:none;">&#8659; expand viewport &#8659;</a></p>'."\n";
							}
							else if($view_log_file && file_exists($logs_dir."/".$view_log_file))
								echo '<textarea id="ws-plugin--optimizemember-log-file-viewer" rows="20" wrap="on" spellcheck="false" style="box-shadow:inset 0 0 5px rgba(0,0,0,0.5); background:#EEEEEE; color:#000000; overflow-y:scroll; font-style:italic;" class="monospace">— Empty at this time —</textarea>' . "\n";

							else if($view_log_file && !file_exists($logs_dir."/".$view_log_file))
								echo '<textarea id="ws-plugin--optimizemember-log-file-viewer" rows="20" wrap="on" spellcheck="false" style="box-shadow:inset 0 0 5px rgba(0,0,0,0.5); background:#EEEEEE; color:#000000; overflow-y:scroll; font-style:italic;" class="monospace">— File no longer exists —</textarea>' . "\n";

							else // Display an empty textarea in this default scenario.
								echo '<textarea id="ws-plugin--optimizemember-log-file-viewer" rows="20" wrap="on" spellcheck="false" style="box-shadow:inset 0 0 5px rgba(0,0,0,0.5); background:#EEEEEE; color:#000000; overflow-y:scroll; font-style:italic;" class="monospace"></textarea>' . "\n";

							echo '</td>' . "\n";

							echo '</tr>' . "\n";
							echo '</tbody>' . "\n";
							echo '</table>' . "\n";

							echo '</form>'."\n";

							echo '</div>'."\n";
							echo '</div>'."\n";

							do_action("ws_plugin__optimizemember_during_logs_page_during_left_sections_after_logs", get_defined_vars());
						}

						do_action("ws_plugin__optimizemember_during_logs_page_after_left_sections", get_defined_vars());

						echo '</td>'."\n";

						echo '<td class="ws-menu-page-table-r">'."\n";
						c_ws_plugin__optimizemember_menu_pages_rs::display();
						echo '</td>'."\n";

						echo '</tr>'."\n";
						echo '</tbody>'."\n";
						echo '</table>'."\n";

						echo '</div>'."\n";
                        echo '</div>' . "\n";
					}
			}
	}

new c_ws_plugin__optimizemember_menu_page_logs();
?>