= Is optimizeMember compatible with WordPress Multisite Networking? =
Yes. optimizeMember and optimizeMember Pro are both compatible with Multisite Networking. After you enable Multisite Networking, install the optimizeMember plugin. Then navigate to `optimizeMember -> Multisite (Config)` in the Dashboard on your Main Site. You can get started now, by turning on [Multisite Networking](http://codex.wordpress.org/Create_A_Network) inside your installation of WordPress.

You can learn more about optimizeMember at [optimizeMember.com](http://www.optimizeMember.com/).