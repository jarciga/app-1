<?php
/**
* Handles various importations ( inner processing routines ).
*
* Copyright: © 2009-2011
* {@link http://www.optimizepress.com/ optimizePress, Inc.}
* ( coded in the USA )
*
* This WordPress plugin ( optimizeMember Pro ) is comprised of two parts:
*
* o (1) Its PHP code is licensed under the GPL license, as is WordPress.
* 	You should have received a copy of the GNU General Public License,
* 	along with this software. In the main directory, see: /licensing/
* 	If not, see: {@link http://www.gnu.org/licenses/}.
*
* o (2) All other parts of ( optimizeMember Pro ); including, but not limited to:
* 	the CSS code, some JavaScript code, images, and design;
* 	are licensed according to the license purchased.
* 	See: {@link http://www.optimizepress.com/prices/}
*
* Unless you have our prior written consent, you must NOT directly or indirectly license,
* sub-license, sell, resell, or provide for free; part (2) of the optimizeMember Pro Module;
* or make an offer to do any of these things. All of these things are strictly
* prohibited with part (2) of the optimizeMember Pro Module.
*
* Your purchase of optimizeMember Pro includes free lifetime upgrades via optimizeMember.com
* ( i.e. new features, bug fixes, updates, improvements ); along with full access
* to our video tutorial library: {@link http://www.optimizepress.com/videos/}
*
* @package optimizeMember\Imports
* @since 1.5
*/
if(!defined('WPINC'))
	exit("Do not access this file directly.");
/**/
if(!class_exists("c_ws_plugin__optimizemember_pro_imports_in"))
	{
		/**
		* Handles various importations ( inner processing routines ).
		*
		* @package optimizeMember\Imports
		* @since 1.5
		*/
		class c_ws_plugin__optimizemember_pro_imports_in
			{
				/**
				* Handles the importation of Users/Members.
				*
				* @package optimizeMember\Imports
				* @since 110815
				*
				* @return null
				*/
				public static function import_users()
					{
						if(!empty($_POST["ws_plugin__optimizemember_pro_import_users"]) && ($nonce = $_POST["ws_plugin__optimizemember_pro_import_users"]) && wp_verify_nonce($nonce, "ws-plugin--optimizemember-pro-import-users") && current_user_can("create_users"))
							{
								global /* Global database object reference. */ $wpdb;
								global /* Multisite Networking. */ $current_site, $current_blog;
								/**/
								@set_time_limit /* Make time for processing large import files. */(0);
								@ini_set("memory_limit", apply_filters("admin_memory_limit", WP_MAX_MEMORY_LIMIT));
								/**/
								remove_all_actions("profile_update").remove_all_actions("user_register");
								remove_all_actions("added_existing_user").remove_all_actions("add_user_to_blog");
								/**/
								if(!empty($_FILES["ws_plugin__optimizemember_pro_import_users_file"]) && empty($_FILES["ws_plugin__optimizemember_pro_import_users_file"]["error"]))
									$file = fopen($_FILES["ws_plugin__optimizemember_pro_import_users_file"]["tmp_name"], "r");
								/**/
								else if(!empty($_POST["ws_plugin__optimizemember_pro_import_users_direct_input"]))
									fwrite(($file = tmpfile()), trim(stripslashes($_POST["ws_plugin__optimizemember_pro_import_users_direct_input"]))).fseek($file, 0);
								/**/
								if /* Only process if we have a resource. */(isset($file) && is_resource($file) && !($imported = 0))
									{
										$custom_field_vars = /* Initialize this array. */ array();
										if($GLOBALS["WS_PLUGIN__"]["optimizemember"]["o"]["custom_reg_fields"])
											foreach(json_decode($GLOBALS["WS_PLUGIN__"]["optimizemember"]["o"]["custom_reg_fields"], TRUE) as $field)
											{
												$custom_field_var = preg_replace("/[^a-z0-9]/i", "_", strtolower($field["id"]));
												$custom_field_vars[] = $custom_field_var;
											}
										sort /* Always sort this array. */($custom_field_vars, SORT_STRING);
										/**/
										while(($data = ((version_compare(PHP_VERSION, "5.3", ">=")) ? fgetcsv($file, 0, ",", '"', '"') : fgetcsv($file, 0, ",", '"'))) !== false)
											{
												$line = /* CSV lines. */ (int)$line + 1;
												/**/
												$data = c_ws_plugin__optimizemember_utils_strings::trim_deep($data);
												$data = stripslashes_deep($data);
												/**/
												if /* Skip first line if it contains headers. */($line === 1 && strtoupper($data[0]) === "ID")
													{
														$line = $line - 1;
														continue;
													}
												if(is_multisite() && c_ws_plugin__optimizemember_utils_conds::is_multisite_farm() && !is_main_site())
													{
														$ID = $data[0];
														/**/
														$user_login = preg_replace("/\s+/", "", sanitize_user($data[1], is_multisite()));
														$user_pass = (string)"";
														/**/
														$first_name = $data[2];
														$last_name = $data[3];
														$display_name = $data[4];
														/**/
														$user_email = sanitize_email($data[5]);
														$user_url = $data[6];
														/**/
														$role = $data[7];
														$custom_capabilities = $data[8];
														/**/
														$user_registered = ($data[9]) ? date("Y-m-d H:i:s", strtotime($data[9])) : "";
														$paid_registration_times = ($data[10]) ? maybe_unserialize($data[10]) : "";
														$last_payment_time = ($data[11]) ? strtotime($data[11]) : "";
														$auto_eot_time = ($data[12]) ? strtotime($data[12]) : "";
														/**/
														$custom = $data[13];
														$subscr_id = $data[14];
														$subscr_gateway = strtolower($data[15]);
														/**/
														$custom_fields = /* Initialize. */ array();
														if /* Now loop through Custom Fields. */(count($data) > 16)
															for($i = 16, $j = 0; $i < count($data); $i++, $j++)
																if /* A field in this position? */ (isset($custom_field_vars[$j]))
																	$custom_fields[$custom_field_vars[$j]] = maybe_unserialize($data[$i]);
													}
												else /* Otherwise, we use the standardized format for importation.*/
													{
														$ID = $data[0];
														/**/
														$user_login = preg_replace("/\s+/", "", sanitize_user($data[1], is_multisite()));
														$user_pass = $data[2];
														/**/
														$first_name = $data[3];
														$last_name = $data[4];
														$display_name = $data[5];
														/**/
														$user_email = sanitize_email($data[6]);
														$user_url = $data[7];
														/**/
														$role = $data[8];
														$custom_capabilities = $data[9];
														/**/
														$user_registered = ($data[10]) ? date("Y-m-d H:i:s", strtotime($data[10])) : "";
														$paid_registration_times = ($data[11]) ? maybe_unserialize($data[11]) : "";
														$last_payment_time = ($data[12]) ? strtotime($data[12]) : "";
														$auto_eot_time = ($data[13]) ? strtotime($data[13]) : "";
														/**/
														$custom = $data[14];
														$subscr_id = $data[15];
														$subscr_gateway = strtolower($data[16]);
														/**/
														$custom_fields = /* Initialize. */ array();
														if /* Now loop through Custom Fields. */(count($data) > 17)
															for($i = 17, $j = 0; $i < count($data); $i++, $j++)
																if /* A field in this position? */ (isset($custom_field_vars[$j]))
																	$custom_fields[$custom_field_vars[$j]] = maybe_unserialize($data[$i]);
													}
												$role = (is_numeric($role)) ? (($role == 0) ? "subscriber" : "optimizemember_level".$role) : $role;
												/**/
												if($paid_registration_times && !is_array($paid_registration_times))
													$paid_registration_times = array("level" => strtotime($paid_registration_times));
												$paid_registration_times = (!$paid_registration_times || !is_array($paid_registration_times)) ? array(): $paid_registration_times;
												/**/
												$user_details = compact("ID", "user_login", "user_pass", "first_name", "last_name", "display_name", "user_email", "user_url", "role", "user_registered");
												if(empty($user_details["user_pass"])) /* If there was NO Password given. */
													unset($user_details["user_pass"]); /* Unset the Password array element. */
												/**/
												if($ID) /* Are we dealing with an existing User ID? */
													{
														if(is_object($user = new WP_User($ID)) && $user->ID) /* Is this User in the database? */
															{
																if(!is_multisite() || is_user_member_of_blog($ID)) /* Must be a Member of this Blog. */
																	{
																		if((!is_multisite() || !is_super_admin($ID)) && !$user->has_cap("administrator"))
																			{
																				if(strtolower($role) !== "administrator") /* Do NOT update to Administrator. */
																					{
																						if($user_email && is_email($user_email)) /* Is the email address valid? */
																							{
																								if($user_login) /* Has a Username ( aka: user_login ) been supplied? */
																									{
																										if(validate_username($user_login)) /* Is the Username valid? */
																											{
																												if(($_same_email = (strtolower($user_email) === strtolower($user->user_email))) || !email_exists($user_email))
																													{
																														if(($_same_login = (strtolower($user_login) === strtolower($user->user_login))) || !username_exists($user_login))
																															{
																																if(!is_multisite() || ($_same_email && $_same_login) || (($_ = wpmu_validate_user_signup($user_login, $user_email)) && (!is_wp_error($_["errors"]) || !$_["errors"]->get_error_code())))
																																	{
																																		if(is_multisite() && c_ws_plugin__optimizemember_utils_conds::is_multisite_farm() && !is_main_site())
																																			unset($user_details["user_login"], $user_details["user_pass"]);
																																		/**/
																																		if(($user_id = wp_update_user($user_details)))
																																			{
																																				update_user_option($user_id, "optimizemember_custom", $custom);
																																				update_user_option($user_id, "optimizemember_subscr_id", $subscr_id);
																																				update_user_option($user_id, "optimizemember_subscr_gateway", $subscr_gateway);
																																				update_user_option($user_id, "optimizemember_auto_eot_time", $auto_eot_time);
																																				update_user_option($user_id, "optimizemember_paid_registration_times", $paid_registration_times);
																																				update_user_option($user_id, "optimizemember_last_payment_time", $last_payment_time);
																																				update_user_option($user_id, "optimizemember_custom_fields", $custom_fields);
																																				/**/
																																				foreach($user->allcaps as $cap => $cap_enabled)
																																					if(preg_match("/^access_optimizemember_ccap_/", $cap))
																																						$user->remove_cap($ccap = $cap);
																																				/**/
																																				if($custom_capabilities && preg_replace("/^-all[\r\n\t\s;,]*/", "", str_replace("+", "", $custom_capabilities)))
																																					foreach(preg_split("/[\r\n\t\s;,]+/", preg_replace("/^-all[\r\n\t\s;,]*/", "", str_replace("+", "", $custom_capabilities))) as $ccap)
																																						if(strlen($ccap = trim(strtolower(preg_replace("/[^a-z_0-9]/i", "", $ccap)))))
																																							$user->add_cap("access_optimizemember_ccap_".$ccap);
																																				/**/
																																				$imported = $imported + 1;
																																			}
																																		else
																																			$errors[] = "Line #".$line.". User ID# <code>".$ID."</code> could NOT be updated. Unknown error, please try again.";
																																	}
																																else
																																	$errors[] = "Line #".$line.". Network. The Username and/or Email ( <code>".esc_html($user_login)."</code> / <code>".esc_html($user_email)."</code> ) are in conflict w/ Network rules.";
																															}
																														else
																															$errors[] = "Line #".$line.". Conflicting. The Username ( <code>".esc_html($user_login)."</code> ), already exists.";
																													}
																												else
																													$errors[] = "Line #".$line.". Conflicting. The Email address ( <code>".esc_html($user_email)."</code> ), already exists.";
																											}
																										else
																											$errors[] = "Line #".$line.". Invalid Username ( <code>".esc_html($user_login)."</code> ). Lowercase alphanumerics are required.";
																									}
																								else
																									$errors[] = "Line #".$line.". Missing Username; please try again."; /* We have two separate errors for Usernames. This provides clarity. */
																							}
																						else
																							$errors[] = "Line #".$line.". Missing or invalid Email address ( <code>".esc_html($user_email)."</code> ); please try again.";
																					}
																				else
																					$errors[] = "Line #".$line.". User ID# <code>".$ID."</code> cannot be updated to an Administrator. Bypassing this line for security.";
																			}
																		else
																			$errors[] = "Line #".$line.". User ID# <code>".$ID."</code> belongs to an Administrator. Bypassing this line for security.";
																	}
																else
																	$errors[] = "Line #".$line.". User ID# <code>".$ID."</code> does NOT belong to an existing User on this site.";
															}
														else
															$errors[] = "Line #".$line.". User ID# <code>".$ID."</code> does NOT belong to an existing User.";
													}
												/**/
												else if(is_multisite() && ($user_id = c_ws_plugin__optimizemember_utils_users::ms_user_login_email_exists_but_not_on_blog($user_login, $user_email)) && !is_super_admin($user_id))
													{
														if(strtolower($role) !== "administrator") /* Do NOT add existing Users as Administrators. */
															{
																if(add_existing_user_to_blog(array("user_id" => $user_id, "role" => $role)))
																	{
																		if(is_object($user = new WP_User($user_id)) && $user->ID)
																			{
																				update_user_option($user_id, "optimizemember_custom", $custom);
																				update_user_option($user_id, "optimizemember_subscr_id", $subscr_id);
																				update_user_option($user_id, "optimizemember_subscr_gateway", $subscr_gateway);
																				update_user_option($user_id, "optimizemember_auto_eot_time", $auto_eot_time);
																				update_user_option($user_id, "optimizemember_paid_registration_times", $paid_registration_times);
																				update_user_option($user_id, "optimizemember_last_payment_time", $last_payment_time);
																				update_user_option($user_id, "optimizemember_custom_fields", $custom_fields);
																				/**/
																				foreach($user->allcaps as $cap => $cap_enabled)
																					if(preg_match("/^access_optimizemember_ccap_/", $cap))
																						$user->remove_cap($ccap = $cap);
																				/**/
																				if($custom_capabilities && preg_replace("/^-all[\r\n\t\s;,]*/", "", str_replace("+", "", $custom_capabilities)))
																					foreach(preg_split("/[\r\n\t\s;,]+/", preg_replace("/^-all[\r\n\t\s;,]*/", "", str_replace("+", "", $custom_capabilities))) as $ccap)
																						if(strlen($ccap = trim(strtolower(preg_replace("/[^a-z_0-9]/i", "", $ccap)))))
																							$user->add_cap("access_optimizemember_ccap_".$ccap);
																				/**/
																				$imported = $imported + 1;
																			}
																		else
																			$errors[] = "Line #".$line.". Unknown object error, please try again.";
																	}
																else
																	$errors[] = "Line #".$line.". Unknown User/site addition error, please try again.";
															}
														else
															$errors[] = "Line #".$line.". Role cannot be Administrator. Bypassing this line for security.";
													}
												/**/
												else /* Otherwise, we are adding a brand new User. */
													{
														if(strtolower($role) !== "administrator") /* Admin? */
															{
																if($user_email && is_email($user_email) /* Valid? */)
																	{
																		if($user_login) /* Was a Username even supplied? */
																			{
																				if(validate_username($user_login)) /* Is it valid? */
																					{
																						if(!email_exists($user_email) /* Exists already? */)
																							{
																								if(!username_exists($user_login) /* Exists? */)
																									{
																										if(!is_multisite() || (($_ = wpmu_validate_user_signup($user_login, $user_email)) && (!is_wp_error($_["errors"]) || !$_["errors"]->get_error_code())))
																											{
																												if(($user_id = wp_insert_user($user_details)))
																													{
																														if(is_object($user = new WP_User($user_id)) && $user->ID)
																															{
																																if($user_pass) /* If we are given an "un-encrypted Password". */
																																	wp_update_user(array("ID" => $user_id, "user_pass" => $user_pass));
																																/**/
																																if(is_multisite()) /* New Users on a Multisite Network need this too. */
																																	update_user_meta($user_id, "optimizemember_originating_blog", $current_blog->blog_id);
																																/**/
																																update_user_option($user_id, "optimizemember_custom", $custom);
																																update_user_option($user_id, "optimizemember_subscr_id", $subscr_id);
																																update_user_option($user_id, "optimizemember_subscr_gateway", $subscr_gateway);
																																update_user_option($user_id, "optimizemember_auto_eot_time", $auto_eot_time);
																																update_user_option($user_id, "optimizemember_paid_registration_times", $paid_registration_times);
																																update_user_option($user_id, "optimizemember_last_payment_time", $last_payment_time);
																																update_user_option($user_id, "optimizemember_custom_fields", $custom_fields);
																																/**/
																																foreach($user->allcaps as $cap => $cap_enabled)
																																	if(preg_match("/^access_optimizemember_ccap_/", $cap))
																																		$user->remove_cap($ccap = $cap);
																																/**/
																																if($custom_capabilities && preg_replace("/^-all[\r\n\t\s;,]*/", "", str_replace("+", "", $custom_capabilities)))
																																	foreach(preg_split("/[\r\n\t\s;,]+/", preg_replace("/^-all[\r\n\t\s;,]*/", "", str_replace("+", "", $custom_capabilities))) as $ccap)
																																		if(strlen($ccap = trim(strtolower(preg_replace("/[^a-z_0-9]/i", "", $ccap)))))
																																			$user->add_cap("access_optimizemember_ccap_".$ccap);
																																/**/
																																$imported = $imported + 1;
																															}
																														else
																															$errors[] = "Line #".$line.". Unknown object error, please try again.";
																													}
																												else
																													$errors[] = "Line #".$line.". Unknown insertion error, please try again.";
																											}
																										else
																											$errors[] = "Line #".$line.". Network. The Username and/or Email ( <code>".esc_html($user_login)."</code> / <code>".esc_html($user_email)."</code> ) are in conflict w/ Network rules.";
																									}
																								else
																									$errors[] = "Line #".$line.". Conflicting. The Username ( <code>".esc_html($user_login)."</code> ), already exists.";
																							}
																						else
																							$errors[] = "Line #".$line.". Conflicting. The Email address ( <code>".esc_html($user_email)."</code> ), already exists.";
																					}
																				else
																					$errors[] = "Line #".$line.". Invalid Username ( <code>".esc_html($user_login)."</code> ). Lowercase alphanumerics are required.";
																			}
																		else
																			$errors[] = "Line #".$line.". Missing Username; please try again."; /* We have two separate errors for Usernames. This provides clarity. */
																	}
																else
																	$errors[] = "Line #".$line.". Missing or invalid Email address ( <code>".esc_html($user_email)."</code> ); please try again.";
															}
														else
															$errors[] = "Line #".$line.". Role cannot be Administrator. Bypassing this line for security.";
													}
											}
										/**/
										fclose($file);
									}
								else
									$errors[] = "No data was received. Please try again."; /* The upload failed, or it was empty. */
								/**/
								c_ws_plugin__optimizemember_admin_notices::display_admin_notice('Operation complete. Users/Members imported: <code>'.(int)$imported.'</code>.');
								/**/
								if(!empty($errors)) /* Here is where a detailed error log will be returned to the Site Owner; as a way of clarifying what just happened during importation. */
									c_ws_plugin__optimizemember_admin_notices::display_admin_notice('<strong>The following errors were encountered during importation:</strong><ul style="font-size:80%; list-style:disc outside; margin-left:25px;"><li>'.implode("</li><li>", $errors).'</li></ul>', true);
							}
						/**/
						return; /* Return for uniformity. */
					}
				/**
				* Handles the importation of options.
				*
				* @package optimizeMember\Imports
				* @since 110815
				*
				* @return null
				*/
				public static function import_ops()
					{
						if(!empty($_POST["ws_plugin__optimizemember_pro_import_ops"]) && ($nonce = $_POST["ws_plugin__optimizemember_pro_import_ops"]) && wp_verify_nonce($nonce, "ws-plugin--optimizemember-pro-import-ops") && current_user_can("create_users"))
							{
								@set_time_limit(0); /* Make time for processing large import files. */
								@ini_set("memory_limit", apply_filters("admin_memory_limit", WP_MAX_MEMORY_LIMIT));
								/**/
								if(!empty($_FILES["ws_plugin__optimizemember_pro_import_ops_file"]) && empty($_FILES["ws_plugin__optimizemember_pro_import_ops_file"]["error"]))
									$file = file_get_contents($_FILES["ws_plugin__optimizemember_pro_import_ops_file"]["tmp_name"], "r");
								/**/
								if(!empty($file)) /* Only process if we have an importation file. */
									{
										if(is_array($import = c_ws_plugin__optimizemember_pro_utils_ops::op_replace(@unserialize($file), true)) && !empty($import) && ($import["configured"] = "1"))
											{
												unset($import["options_checksum"], $import["options_version"]);
												/**/
												foreach($import as $key => $value) /* Add prefixes now. */
													{
														(is_array($value)) ? array_unshift($value, "update-signal") : null;
														$import["ws_plugin__optimizemember_".$key] = $value;
														unset($import[$key]);
													}
												/**/
												c_ws_plugin__optimizemember_menu_pages::update_all_options($import, true, true, false, false, false);
											}
										else
											$errors[] = "Invalid data received. Please try again."; /* Unserialization failed? */
									}
								else
									$errors[] = "No data was received. Please try again."; /* The upload failed, or it was empty. */
								/**/
								if(!empty($errors)) /* Here is where a detailed error log will be returned to the Site Owner; as a way of clarifying what just happened during importation. */
									c_ws_plugin__optimizemember_admin_notices::display_admin_notice('<strong>The following errors were encountered during importation:</strong><ul style="font-size:80%; list-style:disc outside; margin-left:25px;"><li>'.implode("</li><li>", $errors).'</li></ul>', true);
								else
									c_ws_plugin__optimizemember_admin_notices::display_admin_notice('Operation complete. Options imported.');
							}
						/**/
						return; /* Return for uniformity. */
					}
			}
	}
?>