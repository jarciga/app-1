<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit("Do not access this file directly.");
?>

[optimizeMember-Pro-ClickBank-Button cbp="%%item%%" cbskin="" cbfid="" cbur="" cbf="auto" level="*" ccaps="music,videos" desc="<?php echo esc_attr (_x ("Description and pricing details here.", "s2member-admin", "s2member")); ?>" custom="%%custom%%" rp="1" rt="L" rr="0" image="default" output="anchor" /]