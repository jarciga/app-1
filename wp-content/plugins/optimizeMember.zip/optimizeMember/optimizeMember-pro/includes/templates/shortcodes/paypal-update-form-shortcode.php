<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit("Do not access this file directly.");
?>

[optimizeMember-Pro-PayPal-Form update="1" desc="<?php echo esc_attr (_x ("Update your billing information.", "s2member-front", "s2member")); ?>" accept="paypal,visa,mastercard,amex,discover,maestro,solo" default_country_code="" captcha="0" /]